import React from "react";
import { ShipmentAlert } from "@/types";
import { AlertCircle, X } from "lucide-react";
import { 
  Alert,
  AlertDescription,
  AlertTitle
} from "@/components/ui/alert";

interface AlertBannerProps {
  alert: ShipmentAlert;
  onDismiss: (id: number) => void;
}

export function AlertBanner({ alert, onDismiss }: AlertBannerProps) {
  // Determine background color based on alert type
  const getBgClass = (type: string) => {
    switch (type) {
      case 'delay':
        return 'bg-amber-50 border-l-4 border-amber-500';
      case 'temperature':
      case 'issue':
        return 'bg-red-50 border-l-4 border-red-500';
      default:
        return 'bg-blue-50 border-l-4 border-blue-500';
    }
  };

  // Determine alert icon color
  const getIconColorClass = (type: string) => {
    switch (type) {
      case 'delay':
        return 'text-amber-500';
      case 'temperature':
      case 'issue':
        return 'text-red-500';
      default:
        return 'text-blue-500';
    }
  };

  // Determine text color for title
  const getTitleColorClass = (type: string) => {
    switch (type) {
      case 'delay':
        return 'text-amber-800';
      case 'temperature':
      case 'issue':
        return 'text-red-800';
      default:
        return 'text-blue-800';
    }
  };

  // Determine text color for description
  const getDescColorClass = (type: string) => {
    switch (type) {
      case 'delay':
        return 'text-amber-700';
      case 'temperature':
      case 'issue':
        return 'text-red-700';
      default:
        return 'text-blue-700';
    }
  };

  // Format alert title based on type
  const getAlertTitle = (type: string) => {
    switch (type) {
      case 'delay':
        return 'Shipment Delay Alert';
      case 'temperature':
        return 'Temperature Alert';
      case 'issue':
        return 'Shipment Issue Alert';
      default:
        return 'Shipment Alert';
    }
  };

  return (
    <Alert className={`mb-6 rounded shadow-sm animate-pulse ${getBgClass(alert.alertType)}`}>
      <div className="flex items-start">
        <div className="flex-shrink-0">
          <AlertCircle className={`h-5 w-5 ${getIconColorClass(alert.alertType)}`} />
        </div>
        <div className="ml-3">
          <AlertTitle className={`text-sm font-medium ${getTitleColorClass(alert.alertType)}`}>
            {getAlertTitle(alert.alertType)}
          </AlertTitle>
          <AlertDescription className={`mt-1 text-sm ${getDescColorClass(alert.alertType)}`}>
            {alert.message}
          </AlertDescription>
          <div className="mt-2">
            <button type="button" className={`text-xs ${getTitleColorClass(alert.alertType)} font-medium hover:underline`}>
              View Details
            </button>
          </div>
        </div>
        <div className="ml-auto pl-3">
          <div className="-mx-1.5 -my-1.5">
            <button 
              onClick={() => onDismiss(alert.id)} 
              type="button" 
              className={`inline-flex rounded-md p-1.5 ${getIconColorClass(alert.alertType)} hover:bg-${alert.alertType === 'delay' ? 'amber' : 'red'}-100 focus:outline-none`}
            >
              <span className="sr-only">Dismiss</span>
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </Alert>
  );
}
