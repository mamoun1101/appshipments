import React, { useState, useEffect } from "react";
import { ShipmentFilters, Customer } from "@/types";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { RotateCw, CalendarIcon } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";

interface FilterBarProps {
  filters: ShipmentFilters;
  onFilterChange: (filters: ShipmentFilters) => void;
  onResetFilters: () => void;
}

export function FilterBar({ 
  filters, 
  onFilterChange, 
  onResetFilters 
}: FilterBarProps) {
  // Fetch customers for the dropdown
  const { data: customers = [] } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });
  
  // State for date pickers
  const [fromDate, setFromDate] = useState<Date | undefined>(undefined);
  const [toDate, setToDate] = useState<Date | undefined>(undefined);
  
  // Initialize date pickers when switching to custom range
  useEffect(() => {
    // This resets the dates when switching away from custom
    if (filters.dateRange !== 'custom') {
      setFromDate(undefined);
      setToDate(undefined);
    }
    
    // When we switch to custom, try to initialize with existing date filters
    if (filters.dateRange === 'custom') {
      if (filters.dateFrom) {
        try {
          setFromDate(new Date(filters.dateFrom));
        } catch (e) {
          console.error("Invalid dateFrom format:", e);
        }
      }
      
      if (filters.dateTo) {
        try {
          setToDate(new Date(filters.dateTo));
        } catch (e) {
          console.error("Invalid dateTo format:", e);
        }
      }
    }
  }, [filters.dateRange]);

  // Handle input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({
      ...filters,
      [e.target.name]: e.target.value
    });
  };

  // Handle select changes
  const handleSelectChange = (name: string, value: string) => {
    // If "all" is selected, remove that filter by setting it to undefined
    const filterValue = value === 'all' ? undefined : value;
    
    // Clear custom date range if date range type changed
    if (name === 'dateRange' && value !== 'custom') {
      setFromDate(undefined);
      setToDate(undefined);
      
      // Remove dateFrom and dateTo when changing away from custom
      onFilterChange({
        ...filters,
        [name]: filterValue,
        dateFrom: undefined,
        dateTo: undefined
      });
    } else {
      onFilterChange({
        ...filters,
        [name]: filterValue
      });
    }
  };

  return (
    <div>
      <Card className="bg-white rounded-lg shadow-sm p-4 mb-6 flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
        <div className="flex-1">
          <Label htmlFor="shipmentId" className="block text-sm font-medium text-gray-700 mb-1">
            Shipment ID
          </Label>
          <Input
            id="shipmentId"
            name="shipmentId"
            placeholder="Enter shipment ID"
            value={filters.shipmentId || ''}
            onChange={handleInputChange}
            className="w-full border border-gray-300 rounded-md shadow-sm sm:text-sm p-2"
          />
        </div>
        
        <div className="flex-1">
          <Label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
            Status
          </Label>
          <Select
            value={filters.status || 'all'}
            onValueChange={(value) => handleSelectChange('status', value)}
          >
            <SelectTrigger id="status" className="w-full">
              <SelectValue placeholder="All Statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="in-transit">In Transit</SelectItem>
              <SelectItem value="delayed">Delayed</SelectItem>
              <SelectItem value="delivered">Delivered</SelectItem>
              <SelectItem value="issue">Has Issue</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex-1">
          <Label htmlFor="customerId" className="block text-sm font-medium text-gray-700 mb-1">
            Customer
          </Label>
          <Select
            value={filters.customerId || 'all'}
            onValueChange={(value) => handleSelectChange('customerId', value)}
          >
            <SelectTrigger id="customerId" className="w-full">
              <SelectValue placeholder="All Customers" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Customers</SelectItem>
              {customers.map((customer) => (
                <SelectItem key={customer.id} value={customer.id.toString()}>
                  {customer.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex-1">
          <Label htmlFor="dateRange" className="block text-sm font-medium text-gray-700 mb-1">
            Date Range
          </Label>
          <Select
            value={filters.dateRange || 'all'}
            onValueChange={(value) => handleSelectChange('dateRange', value)}
          >
            <SelectTrigger id="dateRange" className="w-full">
              <SelectValue placeholder="All Dates" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Dates</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="yesterday">Yesterday</SelectItem>
              <SelectItem value="last-7-days">Last 7 Days</SelectItem>
              <SelectItem value="last-30-days">Last 30 Days</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-end">
          <Button
            variant="outline"
            className="w-full bg-gray-100 text-gray-800 hover:bg-gray-200"
            onClick={onResetFilters}
          >
            <RotateCw className="h-4 w-4 mr-1" />
            Reset
          </Button>
        </div>
      </Card>
      
      {/* Custom date range picker */}
      {filters.dateRange === 'custom' && (
        <Card className="p-4 mb-6 bg-gray-50">
          <div className="flex flex-col md:flex-row md:space-x-4 space-y-4 md:space-y-0">
            <div className="flex-1">
              <Label htmlFor="fromDate" className="block text-sm font-medium text-gray-700 mb-1">
                From Date
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full flex justify-between px-3 py-2 text-left font-normal bg-white"
                  >
                    {fromDate ? format(fromDate, "PPP") : "Select start date"}
                    <CalendarIcon className="h-4 w-4 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={fromDate}
                    onSelect={setFromDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="flex-1">
              <Label htmlFor="toDate" className="block text-sm font-medium text-gray-700 mb-1">
                To Date
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full flex justify-between px-3 py-2 text-left font-normal bg-white"
                  >
                    {toDate ? format(toDate, "PPP") : "Select end date"}
                    <CalendarIcon className="h-4 w-4 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={toDate}
                    onSelect={setToDate}
                    disabled={(date) => fromDate ? date < fromDate : false}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          
          <div className="mt-4 flex justify-end">
            <Button 
              type="button" 
              variant="default"
              className="bg-primary text-white ml-2"
              onClick={() => {
                console.log("Apply Date Filter clicked", { fromDate, toDate });
                
                const newFilters = { ...filters };
                // Always include dateRange=custom in the filters
                newFilters.dateRange = 'custom';
                
                if (fromDate) {
                  // Convert to string YYYY-MM-DD format for API
                  const dateStr = fromDate.toISOString().split('T')[0];
                  console.log("Setting dateFrom:", dateStr);
                  newFilters.dateFrom = dateStr;
                }
                
                if (toDate) {
                  // Convert to string YYYY-MM-DD format for API
                  const dateStr = toDate.toISOString().split('T')[0];
                  console.log("Setting dateTo:", dateStr);
                  newFilters.dateTo = dateStr;
                }
                
                // Apply the updated filters
                onFilterChange(newFilters);
              }}
            >
              Apply Date Filter
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
