import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  iconBgColor: string;
  iconColor: string;
  changeValue?: number;
  changeLabel?: string;
  changeDirection?: "up" | "down" | "neutral";
  className?: string;
}

export function StatsCard({
  title,
  value,
  icon,
  iconBgColor,
  iconColor,
  changeValue,
  changeLabel,
  changeDirection = "neutral",
  className
}: StatsCardProps) {
  return (
    <Card className={cn("bg-white rounded-lg shadow-sm", className)}>
      <CardContent className="pt-5">
        <div className="flex items-center">
          <div className={cn("flex-shrink-0 rounded-md p-3", iconBgColor)}>
            {icon}
          </div>
          <div className="ml-5">
            <div className="text-sm font-medium text-gray-500">{title}</div>
            <div className="mt-1 text-2xl font-semibold text-gray-900">{value}</div>
          </div>
        </div>
        
        {(changeValue !== undefined || changeLabel) && (
          <div className="mt-4">
            <div className="flex items-center">
              {changeDirection === "up" && (
                <span className="text-green-500 text-sm font-medium flex items-center">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  {changeValue}%
                </span>
              )}
              
              {changeDirection === "down" && (
                <span className="text-red-500 text-sm font-medium flex items-center">
                  <TrendingDown className="h-4 w-4 mr-1" />
                  {changeValue}%
                </span>
              )}
              
              {changeDirection === "neutral" && (
                <span className="text-gray-500 text-sm font-medium">
                  {changeValue ? `${changeValue}%` : ''}
                </span>
              )}
              
              {changeLabel && (
                <span className="text-gray-500 text-sm ml-2">{changeLabel}</span>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
