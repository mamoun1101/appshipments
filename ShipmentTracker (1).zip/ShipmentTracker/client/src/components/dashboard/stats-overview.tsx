import React from "react";
import { ShipmentStats } from "@/types";
import { StatsCard } from "./stats-card";
import { 
  MapPin, 
  Clock, 
  AlertTriangle, 
  CheckCircle 
} from "lucide-react";

interface StatsOverviewProps {
  stats: ShipmentStats;
}

export function StatsOverview({ stats }: StatsOverviewProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <StatsCard
        title="Total Shipments"
        value={stats.total}
        icon={<MapPin className="h-6 w-6 text-blue-600" />}
        iconBgColor="bg-blue-100"
        iconColor="text-blue-600"
        changeValue={stats.weeklyChange?.total}
        changeLabel="vs last week"
        changeDirection={stats.weeklyChange?.total && stats.weeklyChange.total > 0 ? "up" : "down"}
      />
      
      <StatsCard
        title="In Transit"
        value={stats.inTransit}
        icon={<Clock className="h-6 w-6 text-indigo-600" />}
        iconBgColor="bg-indigo-100"
        iconColor="text-indigo-600"
        changeLabel={stats.inTransit > 0 ? `${Math.round((stats.inTransit / stats.total) * 100)}% of total` : "No shipments in transit"}
        changeDirection="neutral"
      />
      
      <StatsCard
        title="Delayed"
        value={stats.delayed}
        icon={<AlertTriangle className="h-6 w-6 text-amber-600" />}
        iconBgColor="bg-amber-100"
        iconColor="text-amber-600"
        changeValue={stats.weeklyChange?.delayed}
        changeLabel="vs last week"
        changeDirection={stats.weeklyChange?.delayed && stats.weeklyChange.delayed > 0 ? "down" : "up"}
      />
      
      <StatsCard
        title="Delivered"
        value={stats.delivered}
        icon={<CheckCircle className="h-6 w-6 text-emerald-600" />}
        iconBgColor="bg-emerald-100"
        iconColor="text-emerald-600"
        changeValue={stats.weeklyChange?.delivered}
        changeLabel="vs last week"
        changeDirection={stats.weeklyChange?.delivered && stats.weeklyChange.delivered > 0 ? "up" : "down"}
      />
    </div>
  );
}
