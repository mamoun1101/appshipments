import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Menu, 
  X, 
  LayoutDashboard, 
  Package2, 
  Users, 
  Bell, 
  ChartBarStacked, 
  Settings
} from "lucide-react";

export function MobileNav() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();
  
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  const navItems = [
    { path: "/", label: "Dashboard", icon: LayoutDashboard },
    { path: "/shipments", label: "Shipments", icon: Package2 },
    { path: "/customers", label: "Customers", icon: Users },
    { path: "/alerts", label: "Alerts", icon: Bell },
    { path: "/reports", label: "Reports", icon: ChartBarStacked },
    { path: "/settings", label: "Settings", icon: Settings },
  ];
  
  return (
    <>
      {/* Mobile Header */}
      <header className="bg-white shadow-md py-4 px-4 flex justify-between items-center lg:hidden sticky top-0 z-10">
        <div className="flex items-center">
          <button 
            onClick={toggleMenu}
            className="text-gray-500 focus:outline-none mr-2"
            aria-label="Open menu"
          >
            <Menu className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold text-primary">ShipTrack Pro</h1>
        </div>
        <div>
          <div className="h-8 w-8 rounded-full bg-gray-300 flex items-center justify-center">
            <span className="text-sm font-semibold text-gray-700">JD</span>
          </div>
        </div>
      </header>
      
      {/* Mobile Menu (Overlay) */}
      <div className={`fixed inset-0 z-20 bg-gray-800 bg-opacity-50 ${isMenuOpen ? 'block' : 'hidden'}`}>
        <div className="bg-white w-64 min-h-screen p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-primary">ShipTrack Pro</h2>
            <button 
              onClick={toggleMenu}
              className="text-gray-500"
              aria-label="Close menu"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          
          <ul>
            {navItems.map((item) => {
              const isActive = item.path === location;
              const Icon = item.icon;
              
              return (
                <li className="mb-1" key={item.path}>
                  <Link href={item.path}>
                    <a 
                      className={`block px-4 py-2 rounded ${isActive 
                        ? 'text-primary bg-blue-50 font-medium' 
                        : 'text-gray-600 hover:bg-gray-100'}`}
                      onClick={toggleMenu}
                    >
                      <div className="flex items-center">
                        <Icon className="h-5 w-5 mr-2" />
                        {item.label}
                      </div>
                    </a>
                  </Link>
                </li>
              );
            })}
          </ul>
          
          <div className="mt-auto pt-4 border-t border-gray-200 mt-8">
            <div className="flex items-center">
              <div className="h-8 w-8 rounded-full mr-2 bg-gray-300 flex items-center justify-center">
                <span className="text-sm font-semibold text-gray-700">JD</span>
              </div>
              <div className="text-sm">
                <p className="font-semibold text-gray-700">John Davis</p>
                <p className="text-gray-500">Admin</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
