import React from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Package2, 
  Users, 
  Bell, 
  ChartBarStacked, 
  Settings
} from "lucide-react";

export function SidebarNav() {
  const [location] = useLocation();
  
  const navItems = [
    { path: "/", label: "Dashboard", icon: LayoutDashboard },
    { path: "/shipments", label: "Shipments", icon: Package2 },
    { path: "/customers", label: "Customers", icon: Users },
    { path: "/alerts", label: "Alerts", icon: Bell },
    { path: "/reports", label: "Reports", icon: ChartBarStacked },
    { path: "/settings", label: "Settings", icon: Settings },
  ];
  
  return (
    <nav className="bg-white shadow-md w-64 fixed h-full overflow-y-auto hidden lg:block">
      <div className="flex items-center justify-center h-16 border-b">
        <h1 className="text-xl font-bold text-primary">ShipTrack Pro</h1>
      </div>
      
      <div className="py-4">
        <ul>
          {navItems.map((item) => {
            const isActive = item.path === location;
            const Icon = item.icon;
            
            return (
              <li key={item.path}>
                <Link href={item.path}>
                  <a className={cn(
                    "flex items-center px-6 py-3 hover:bg-gray-50",
                    isActive 
                      ? "text-gray-700 bg-gray-100 border-l-4 border-primary" 
                      : "text-gray-600"
                  )}>
                    <Icon className="h-5 w-5 mr-3" />
                    {item.label}
                  </a>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
      
      <div className="absolute bottom-0 w-full border-t border-gray-200">
        <div className="flex items-center px-4 py-3">
          <div className="h-8 w-8 rounded-full mr-2 bg-gray-300 flex items-center justify-center">
            <span className="text-sm font-semibold text-gray-700">JD</span>
          </div>
          <div className="text-sm">
            <p className="font-semibold text-gray-700">John Davis</p>
            <p className="text-gray-500">Admin</p>
          </div>
        </div>
      </div>
    </nav>
  );
}
