import React from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Shipment, Customer } from "@/types";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

interface EditShipmentModalProps {
  shipment: Shipment | null;
  isOpen: boolean;
  onClose: () => void;
}

const editShipmentSchema = z.object({
  shipmentId: z.string().min(1, "Shipment ID is required"),
  customerId: z.coerce.number().int().positive("Please select a customer"),
  originCity: z.string().min(1, "Origin city is required"),
  originState: z.string().min(1, "Origin state is required"),
  originLat: z.string().min(1, "Origin latitude is required"),
  originLng: z.string().min(1, "Origin longitude is required"),
  destinationCity: z.string().min(1, "Destination city is required"),
  destinationState: z.string().min(1, "Destination state is required"),
  destinationLat: z.string().min(1, "Destination latitude is required"),
  destinationLng: z.string().min(1, "Destination longitude is required"),
  currentLat: z.string().min(1, "Current latitude is required"),
  currentLng: z.string().min(1, "Current longitude is required"),
  progress: z.coerce.number().min(0).max(100),
  status: z.string().min(1, "Status is required"),
  shipDate: z.string().min(1, "Ship date is required"),
  estimatedDelivery: z.string().min(1, "Estimated delivery date is required"),
  serviceType: z.string().optional(),
  serviceName: z.string().optional(),
  orderReference: z.string().optional(),
  delayReason: z.string().optional(),
  issueDescription: z.string().optional(),
});

type ShipmentFormValues = z.infer<typeof editShipmentSchema>;

export function EditShipmentModal({ shipment, isOpen, onClose }: EditShipmentModalProps) {
  const { toast } = useToast();

  // Fetch customers for dropdown
  const { data: customers = [] } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });

  // Format date from shipment object for the form
  const formatDateForInput = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
  };

  const form = useForm<ShipmentFormValues>({
    resolver: zodResolver(editShipmentSchema),
    defaultValues: {
      shipmentId: shipment?.shipmentId || '',
      customerId: shipment?.customerId,
      originCity: shipment?.originCity || '',
      originState: shipment?.originState || '',
      originLat: shipment?.originLat || '',
      originLng: shipment?.originLng || '',
      destinationCity: shipment?.destinationCity || '',
      destinationState: shipment?.destinationState || '',
      destinationLat: shipment?.destinationLat || '',
      destinationLng: shipment?.destinationLng || '',
      currentLat: shipment?.currentLat || '',
      currentLng: shipment?.currentLng || '',
      progress: shipment?.progress || 0,
      status: shipment?.status || 'in-transit',
      shipDate: shipment?.shipDate ? formatDateForInput(shipment.shipDate) : '',
      estimatedDelivery: shipment?.estimatedDelivery ? formatDateForInput(shipment.estimatedDelivery) : '',
      serviceType: shipment?.serviceType || '',
      serviceName: shipment?.serviceName || '',
      orderReference: shipment?.orderReference || '',
      delayReason: shipment?.delayReason || '',
      issueDescription: shipment?.issueDescription || '',
    },
  });

  // Update form when shipment changes
  React.useEffect(() => {
    if (shipment && isOpen) {
      form.reset({
        shipmentId: shipment.shipmentId,
        customerId: shipment.customerId,
        originCity: shipment.originCity,
        originState: shipment.originState,
        originLat: shipment.originLat,
        originLng: shipment.originLng,
        destinationCity: shipment.destinationCity,
        destinationState: shipment.destinationState,
        destinationLat: shipment.destinationLat,
        destinationLng: shipment.destinationLng,
        currentLat: shipment.currentLat,
        currentLng: shipment.currentLng,
        progress: shipment.progress,
        status: shipment.status,
        shipDate: shipment.shipDate ? formatDateForInput(shipment.shipDate) : '',
        estimatedDelivery: shipment.estimatedDelivery ? formatDateForInput(shipment.estimatedDelivery) : '',
        serviceType: shipment.serviceType || '',
        serviceName: shipment.serviceName || '',
        orderReference: shipment.orderReference || '',
        delayReason: shipment.delayReason || '',
        issueDescription: shipment.issueDescription || '',
      });
    }
  }, [shipment, isOpen, form]);

  // Status values for dropdown
  const statusOptions = [
    { value: 'in-transit', label: 'In Transit' },
    { value: 'delayed', label: 'Delayed' },
    { value: 'delivered', label: 'Delivered' },
    { value: 'issue', label: 'Issue' }
  ];

  // Service type options for dropdown
  const serviceTypeOptions = [
    { value: 'ground', label: 'Ground' },
    { value: 'express', label: 'Express' },
    { value: 'priority', label: 'Priority' },
    { value: 'economy', label: 'Economy' }
  ];

  const updateShipmentMutation = useMutation({
    mutationFn: async (data: ShipmentFormValues) => {
      // Manually prepare the data with proper date handling
      const preparedData = {
        ...data,
        shipDate: data.shipDate,
        estimatedDelivery: data.estimatedDelivery,
      };
      
      const res = await apiRequest("PATCH", `/api/shipments/${shipment?.shipmentId}`, preparedData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/shipments'] });
      queryClient.invalidateQueries({ queryKey: [`/api/shipments/${shipment?.id}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      toast({
        title: "Shipment Updated",
        description: "Shipment has been successfully updated.",
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update shipment: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ShipmentFormValues) => {
    updateShipmentMutation.mutate(data);
  };

  const generateRandomCoordinates = (type: 'origin' | 'destination' | 'current') => {
    // Generate random coordinates - this is just for demo purposes
    // In a real app, you would use geocoding APIs based on the city/state
    const lat = (Math.random() * 20 + 30).toFixed(6); // Random lat between 30-50
    const lng = (Math.random() * 50 - 120).toFixed(6); // Random lng between -120 to -70
    
    if (type === 'origin') {
      form.setValue('originLat', lat);
      form.setValue('originLng', lng);
    } else if (type === 'destination') {
      form.setValue('destinationLat', lat);
      form.setValue('destinationLng', lng);
    } else {
      form.setValue('currentLat', lat);
      form.setValue('currentLng', lng);
    }
  };

  if (!shipment) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Shipment #{shipment.shipmentId}</DialogTitle>
          <DialogDescription>
            Update the shipment details below. All fields marked with * are required.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="shipmentId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Shipment ID *</FormLabel>
                    <FormControl>
                      <Input {...field} disabled />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="customerId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Customer *</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value?.toString()}
                      value={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select customer" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {customers.map((customer) => (
                          <SelectItem key={customer.id} value={customer.id.toString()}>
                            {customer.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div>
              <h3 className="text-base font-medium mb-2">Status Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status *</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {statusOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="progress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Progress (%) *</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="0" 
                          max="100" 
                          {...field} 
                          placeholder="0" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {form.watch('status') === 'delayed' && (
                  <FormField
                    control={form.control}
                    name="delayReason"
                    render={({ field }) => (
                      <FormItem className="col-span-2">
                        <FormLabel>Delay Reason</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Reason for delay" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
                
                {form.watch('status') === 'issue' && (
                  <FormField
                    control={form.control}
                    name="issueDescription"
                    render={({ field }) => (
                      <FormItem className="col-span-2">
                        <FormLabel>Issue Description</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Description of the issue" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </div>
            </div>
            
            <div>
              <h3 className="text-base font-medium mb-2">Origin Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="originCity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Chicago" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="originState"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>State *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="IL" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="originLat"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Latitude *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="41.878113" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="originLng"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Longitude *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="-87.629799" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <Button 
                type="button" 
                variant="outline" 
                size="sm" 
                className="mt-2"
                onClick={() => generateRandomCoordinates('origin')}
              >
                Generate Coordinates
              </Button>
            </div>
            
            <div>
              <h3 className="text-base font-medium mb-2">Destination Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="destinationCity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="New York" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="destinationState"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>State *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="NY" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="destinationLat"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Latitude *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="40.712776" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="destinationLng"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Longitude *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="-74.005974" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <Button 
                type="button" 
                variant="outline" 
                size="sm" 
                className="mt-2"
                onClick={() => generateRandomCoordinates('destination')}
              >
                Generate Coordinates
              </Button>
            </div>
            
            <div>
              <h3 className="text-base font-medium mb-2">Current Location</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="currentLat"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Current Latitude *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Current latitude" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="currentLng"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Current Longitude *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Current longitude" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <Button 
                type="button" 
                variant="outline" 
                size="sm" 
                className="mt-2"
                onClick={() => generateRandomCoordinates('current')}
              >
                Generate Current Coordinates
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="shipDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ship Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="estimatedDelivery"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Estimated Delivery *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="serviceType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Service Type</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select service type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {serviceTypeOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="serviceName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Service Name</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Next Day Air, Ground Shipping, etc." />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="orderReference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Order Reference</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="PO-12345" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose} 
                disabled={updateShipmentMutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={updateShipmentMutation.isPending}
              >
                {updateShipmentMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}