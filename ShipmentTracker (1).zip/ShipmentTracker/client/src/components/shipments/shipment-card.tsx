import React from "react";
import { Shipment } from "@/types";
import { cn } from "@/lib/utils";
import { StatusBadge } from "@/components/ui/status-badge";
import { ProgressBar } from "@/components/ui/progress-bar";
import { formatDate, formatTime } from "@/lib/shipment-utils";

interface ShipmentCardProps {
  shipment: Shipment;
  isSelected?: boolean;
  onClick?: () => void;
}

export function ShipmentCard({ 
  shipment, 
  isSelected = false, 
  onClick 
}: ShipmentCardProps) {
  // Format delay information
  const getDelayInfo = () => {
    if (shipment.status === "delayed" && shipment.delayReason) {
      return `+${Math.floor(Math.random() * 5)}h delay`;
    }
    return null;
  };

  // Format issue information
  const getIssueInfo = () => {
    if (shipment.status === "issue" && shipment.issueDescription) {
      if (shipment.issueDescription.includes("Temperature")) {
        return "Temperature Alert";
      }
      return "Investigation";
    }
    return null;
  };

  // Generate ETA or delivery time display
  const getTimeDisplay = () => {
    if (shipment.status === "delivered" && shipment.actualDelivery) {
      return (
        <>
          <div className="text-xs font-medium text-gray-500">Delivered</div>
          <div className="text-sm font-semibold">{formatDate(shipment.actualDelivery)}</div>
          <div className="text-xs text-gray-500">{formatTime(shipment.actualDelivery)}</div>
        </>
      );
    } else if (shipment.estimatedDelivery) {
      return (
        <>
          <div className="text-xs font-medium text-gray-500">ETA</div>
          <div className={cn(
            "text-sm font-semibold",
            shipment.status === "delayed" && "text-amber-500"
          )}>
            {formatDate(shipment.estimatedDelivery)}
          </div>
          <div className={cn(
            "text-xs",
            shipment.status === "delayed" ? "text-amber-500" : "text-gray-500"
          )}>
            {getDelayInfo() || formatTime(shipment.estimatedDelivery)}
          </div>
        </>
      );
    } else if (shipment.status === "issue") {
      return (
        <>
          <div className="text-xs font-medium text-gray-500">Status</div>
          <div className="text-sm font-semibold text-red-500">
            {getIssueInfo() || "Issue Detected"}
          </div>
          <div className="text-xs text-red-500">Investigation</div>
        </>
      );
    }
    
    return null;
  };

  return (
    <div 
      className={cn(
        "shipment-card border-b border-gray-200 px-4 py-3 hover:bg-gray-50 cursor-pointer",
        isSelected && "border-l-4 border-primary"
      )}
      onClick={onClick}
      data-shipment-id={shipment.shipmentId}
    >
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center mb-1">
            <span className="text-sm font-medium text-gray-900">#{shipment.shipmentId}</span>
            <StatusBadge status={shipment.status} className="ml-2" />
          </div>
          <div className="flex items-center text-xs text-gray-500 mb-1">
            <span className="font-medium">From:</span>
            <span className="ml-1">{shipment.originCity}, {shipment.originState}</span>
          </div>
          <div className="flex items-center text-xs text-gray-500 mb-1">
            <span className="font-medium">To:</span>
            <span className="ml-1">{shipment.destinationCity}, {shipment.destinationState}</span>
          </div>
          <div className="flex items-center text-xs text-gray-500 mb-1">
            <span className="font-medium">Customer:</span>
            <span className="ml-1">ID: {shipment.customerId}</span>
          </div>
          {shipment.shipDate && (
            <div className="flex items-center text-xs text-gray-500 mb-1">
              <span className="font-medium">Ship Date:</span>
              <span className="ml-1">{formatDate(shipment.shipDate)}</span>
            </div>
          )}
          {(shipment.serviceType || shipment.serviceName) && (
            <div className="flex items-center text-xs text-gray-500">
              <span className="font-medium">Service:</span>
              <span className="ml-1">
                {shipment.serviceType && shipment.serviceType.charAt(0).toUpperCase() + shipment.serviceType.slice(1)}
                {shipment.serviceType && shipment.serviceName && " - "}
                {shipment.serviceName}
              </span>
            </div>
          )}
        </div>
        <div className="text-right">
          {getTimeDisplay()}
        </div>
      </div>
      <div className="mt-2">
        <ProgressBar 
          progress={shipment.progress} 
          status={shipment.status} 
          startLabel={shipment.originCity} 
          endLabel={shipment.destinationCity}
        />
      </div>
    </div>
  );
}
