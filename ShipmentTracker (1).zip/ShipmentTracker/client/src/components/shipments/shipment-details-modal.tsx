import React, { useState } from "react";
import { Shipment, ShipmentUpdate } from "@/types";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { formatDate, formatTime, calculateDistance, formatStatus, formatRelativeTime } from "@/lib/shipment-utils";
import { useQuery } from "@tanstack/react-query";
import { ExternalLink, Edit } from "lucide-react";
import { EditShipmentModal } from "./edit-shipment-modal";

// Add Leaflet types to Window object if not already defined
declare global {
  interface Window {
    L: any;
  }
}

interface ShipmentDetailsModalProps {
  shipment: Shipment | null;
  isOpen: boolean;
  onClose: () => void;
}

export function ShipmentDetailsModal({ 
  shipment, 
  isOpen, 
  onClose 
}: ShipmentDetailsModalProps) {
  // State to manage edit modal
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Fetch full shipment details
  const { data: fullShipmentDetails, isLoading: isLoadingDetails } = useQuery<Shipment>({
    queryKey: shipment ? [`/api/shipments/${shipment.id}`] : [],
    enabled: !!shipment && isOpen,
  });
  
  // Fetch shipment updates/history if shipment is provided
  const { data: updates = [], isLoading: isLoadingUpdates } = useQuery<ShipmentUpdate[]>({
    queryKey: shipment ? [`/api/shipments/${shipment.id}/updates`] : [],
    enabled: !!shipment && isOpen,
  });
  
  // Log for debugging
  React.useEffect(() => {
    if (isOpen && shipment) {
      console.log(`Fetching updates for shipment ID: ${shipment.id} with shipmentId: ${shipment.shipmentId}`);
    }
    
    if (updates && updates.length > 0) {
      console.log(`Loaded ${updates.length} shipment updates:`, updates);
    } else if (shipment && isOpen && !isLoadingUpdates) {
      console.log('No updates found for shipment');
    }
  }, [shipment, isOpen, updates, isLoadingUpdates]);

  if (!shipment) return null;
  
  // Use full details if available, otherwise fall back to the shipment prop
  const shipmentData = fullShipmentDetails || shipment;

  // Calculate distance between origin and destination
  const distance = calculateDistance(
    parseFloat(shipmentData.originLat),
    parseFloat(shipmentData.originLng),
    parseFloat(shipmentData.destinationLat),
    parseFloat(shipmentData.destinationLng)
  );

  return (
    <>
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto z-[999]" style={{ zIndex: 999 }}>
          <DialogHeader>
            <DialogTitle>Shipment #{shipmentData.shipmentId}</DialogTitle>
            <DialogDescription>
              Detailed information about the shipment and its current status.
            </DialogDescription>
          </DialogHeader>
          
          <div className="mt-4 border-t border-gray-200 pt-4 overflow-y-auto pr-2 relative max-h-[calc(80vh-150px)]">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <h4 className="text-sm font-medium text-gray-500">Shipment Information</h4>
                <div className="mt-2 space-y-2">
                  <div>
                    <span className="text-xs text-gray-500">ID:</span>
                    <span className="ml-2 text-sm font-medium">{shipmentData.shipmentId}</span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500">Status:</span>
                    <span className="ml-2">
                      <StatusBadge status={shipmentData.status} />
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500">Customer:</span>
                    <span className="ml-2 text-sm font-medium">ID: {shipmentData.customerId}</span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500">Order Reference:</span>
                    <span className="ml-2 text-sm font-medium">{shipmentData.orderReference || "N/A"}</span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500">Progress:</span>
                    <div className="mt-1 flex items-center">
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className={`h-2.5 rounded-full ${
                            shipmentData.status === "delayed" ? "bg-amber-500" : 
                            shipmentData.status === "issue" ? "bg-red-500" : 
                            shipmentData.status === "delivered" ? "bg-green-500" : 
                            "bg-blue-500"
                          }`} 
                          style={{ width: `${shipmentData.progress}%` }}
                        ></div>
                      </div>
                      <span className="ml-2 text-xs font-medium">{shipmentData.progress}%</span>
                    </div>
                  </div>
                  {shipmentData.status === "delayed" && shipmentData.delayReason && (
                    <div>
                      <span className="text-xs text-gray-500">Delay Reason:</span>
                      <span className="ml-2 text-sm font-medium text-amber-600">{shipmentData.delayReason}</span>
                    </div>
                  )}
                  {shipmentData.status === "issue" && shipmentData.issueDescription && (
                    <div>
                      <span className="text-xs text-gray-500">Issue Description:</span>
                      <span className="ml-2 text-sm font-medium text-red-600">{shipmentData.issueDescription}</span>
                    </div>
                  )}
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Route Information</h4>
                <div className="mt-2 space-y-2">
                  <div>
                    <span className="text-xs text-gray-500">Origin:</span>
                    <span className="ml-2 text-sm font-medium">{shipmentData.originCity}, {shipmentData.originState}</span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500">Destination:</span>
                    <span className="ml-2 text-sm font-medium">{shipmentData.destinationCity}, {shipmentData.destinationState}</span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500">Distance:</span>
                    <span className="ml-2 text-sm font-medium">{distance} miles</span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500">Ship Date:</span>
                    <span className="ml-2 text-sm font-medium">
                      {shipmentData.shipDate ? `${formatDate(shipmentData.shipDate)} (${formatTime(shipmentData.shipDate)})` : "N/A"}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500">ETA:</span>
                    <span className="ml-2 text-sm font-medium">
                      {shipmentData.estimatedDelivery ? `${formatDate(shipmentData.estimatedDelivery)} (${formatTime(shipmentData.estimatedDelivery)})` : "N/A"}
                    </span>
                  </div>
                  {(shipmentData.serviceType || shipmentData.serviceName) && (
                    <div>
                      <span className="text-xs text-gray-500">Service:</span>
                      <span className="ml-2 text-sm font-medium">
                        {shipmentData.serviceType && shipmentData.serviceType.charAt(0).toUpperCase() + shipmentData.serviceType.slice(1)}
                        {shipmentData.serviceType && shipmentData.serviceName && " - "}
                        {shipmentData.serviceName}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <h4 className="text-sm font-medium text-gray-500">Current Location</h4>
              <div className="mt-2">
                <div className="bg-gray-100 p-3 rounded-md">
                  <span className="text-sm">
                    {`Lat: ${shipmentData.currentLat}, Lng: ${shipmentData.currentLng}`} - 
                    Last updated {formatRelativeTime(shipmentData.updatedAt)}
                  </span>
                </div>
                <div className="mb-4 h-[180px] w-full relative rounded-md mt-3 overflow-hidden border border-gray-200">
                  <div className="w-full h-full relative">
                    <div id={`mini-map-${shipmentData.id}`} className="h-full w-full absolute inset-0" style={{ zIndex: 1 }}></div>
                  </div>
                  <div className="absolute top-4 right-4" style={{ zIndex: 1000 }}>
                    <Button variant="secondary" size="sm" className="bg-white bg-opacity-90 shadow-md">
                      <ExternalLink className="h-3 w-3 mr-1" /> View Full Map
                    </Button>
                  </div>
                </div>
                <script type="text/javascript" dangerouslySetInnerHTML={{ 
                  __html: `
                    setTimeout(() => {
                      try {
                        if (window.L && document.getElementById('mini-map-${shipmentData.id}')) {
                          // Clear any existing map instance
                          const existingMap = document.getElementById('mini-map-${shipmentData.id}');
                          if (existingMap) {
                            existingMap.innerHTML = '';
                          }
                          
                          const map = L.map('mini-map-${shipmentData.id}', {
                            zoomControl: true,
                            attributionControl: true,
                            // Prevent map from stealing focus when inside modal
                            keyboard: false,
                            // Set lower than default z-index for map panes
                            zIndex: 10
                          }).setView([${shipmentData.currentLat}, ${shipmentData.currentLng}], 8);
                          
                          // Adjust map container z-index
                          document.querySelector('#mini-map-${shipmentData.id} .leaflet-map-pane').setAttribute('style', 'z-index: 10 !important');
                          document.querySelector('#mini-map-${shipmentData.id} .leaflet-control-container').setAttribute('style', 'z-index: 20 !important');
                          
                          // Set base map layer
                          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                            attribution: '© OpenStreetMap'
                          }).addTo(map);
                          
                          // Current position marker with tooltip
                          const currentMarker = L.marker([${shipmentData.currentLat}, ${shipmentData.currentLng}]).addTo(map);
                          currentMarker.bindTooltip('Current Location');
                          
                          // Origin marker
                          const originMarker = L.marker([${shipmentData.originLat}, ${shipmentData.originLng}]).addTo(map);
                          originMarker.bindTooltip('Origin: ${shipmentData.originCity}');
                          
                          // Destination marker
                          const destMarker = L.marker([${shipmentData.destinationLat}, ${shipmentData.destinationLng}]).addTo(map);
                          destMarker.bindTooltip('Destination: ${shipmentData.destinationCity}');
                          
                          // Route line 
                          const routeLine = L.polyline([
                            [${shipmentData.originLat}, ${shipmentData.originLng}],
                            [${shipmentData.currentLat}, ${shipmentData.currentLng}],
                            [${shipmentData.destinationLat}, ${shipmentData.destinationLng}]
                          ], {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--status-${shipmentData.status}').trim() || '#3B82F6',
                            weight: 3,
                            opacity: 0.7
                          }).addTo(map);
                          
                          // Fit bounds
                          const group = L.featureGroup([currentMarker, originMarker, destMarker]);
                          map.fitBounds(group.getBounds(), { padding: [30, 30] });
                          
                          // Enable satellite & terrain views
                          const baseMaps = {
                            "OpenStreetMap": L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                              attribution: '© OpenStreetMap'
                            }).addTo(map),
                            "Satellite": L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                              attribution: '© Esri'
                            }),
                            "Terrain": L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
                              attribution: '© OpenTopoMap'
                            })
                          };
                          
                          L.control.layers(baseMaps).addTo(map);
                          
                          // Force map to refresh after modal is fully open
                          setTimeout(() => {
                            map.invalidateSize();
                          }, 250);
                        }
                      } catch (error) {
                        console.error('Error initializing map:', error);
                      }
                    }, 250);
                  `
                }} />
              </div>
            </div>
            
            <div className="mt-6">
              <h4 className="text-sm font-medium text-gray-500">Shipment Timeline</h4>
              <div className="mt-2 relative">
                <div className="absolute top-0 bottom-0 left-3 w-0.5 bg-gray-200"></div>
                
                {updates.map((update, index) => (
                  <div key={update.id} className="relative pl-8 pb-6">
                    <div className={`absolute left-0 top-1 ${getStatusIconColor(update.status)} rounded-full w-6 h-6 flex items-center justify-center`}>
                      {getStatusIcon(update.status)}
                    </div>
                    <p className="text-sm font-medium">
                      {formatUpdateStatus(update.status)}
                      {update.location && ` - ${update.location}`}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatDate(update.timestamp)} - {formatTime(update.timestamp)}
                    </p>
                    {update.description && (
                      <p className="mt-1 text-xs text-gray-600">{update.description}</p>
                    )}
                  </div>
                ))}
                
                {updates.length === 0 && (
                  <div className="pl-8 py-4 text-sm text-gray-500">
                    No timeline entries available
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              className="border border-gray-300 flex items-center"
              onClick={() => setIsEditModalOpen(true)}
            >
              <Edit className="h-4 w-4 mr-2" />
              Edit Shipment
            </Button>
            <Button
              type="button"
              className="bg-primary text-white hover:bg-blue-800"
            >
              Update Status
            </Button>
            <Button
              type="button"
              variant="outline"
              className="border border-gray-300"
            >
              Generate Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Shipment Modal */}
      <EditShipmentModal 
        shipment={shipmentData} 
        isOpen={isEditModalOpen} 
        onClose={() => setIsEditModalOpen(false)}
      />
    </>
  );
}

// Helper functions for timeline

function getStatusIconColor(status: string): string {
  switch (status.toLowerCase()) {
    case 'in-transit':
    case 'departed':
      return 'bg-blue-500';
    case 'delivered':
    case 'received':
      return 'bg-green-500';
    case 'delayed':
      return 'bg-amber-500';
    case 'issue':
      return 'bg-red-500';
    default:
      return 'bg-gray-500';
  }
}

function getStatusIcon(status: string): JSX.Element {
  switch (status.toLowerCase()) {
    case 'in-transit':
      return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
        </svg>
      );
    case 'departed':
      return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
        </svg>
      );
    case 'delivered':
      return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
        </svg>
      );
    case 'received':
      return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
        </svg>
      );
    default:
      return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      );
  }
}

function formatUpdateStatus(status: string): string {
  // Format status with proper capitalization
  return status.split('-').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
}
