import React, { useState } from "react";
import { Shipment } from "@/types";
import { Card } from "@/components/ui/card";
import { ShipmentCard } from "./shipment-card";
import { formatRelativeTime } from "@/lib/shipment-utils";

interface ShipmentListProps {
  shipments: Shipment[];
  isLoading: boolean;
  selectedShipmentId?: string;
  onSelectShipment: (shipmentId: string) => void;
}

export function ShipmentList({ 
  shipments, 
  isLoading, 
  selectedShipmentId,
  onSelectShipment 
}: ShipmentListProps) {
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  
  // Handle refresh button click
  const handleRefresh = () => {
    setLastUpdated(new Date());
    // The actual data refresh is handled by React Query
  };
  
  // Format the last updated time
  const formatLastUpdated = () => {
    return formatRelativeTime(lastUpdated.toISOString());
  };

  return (
    <Card className="bg-white rounded-lg shadow-sm overflow-hidden h-[500px] lg:h-[600px] flex flex-col">
      <div className="bg-gray-50 px-4 py-3 flex items-center justify-between border-b">
        <h3 className="text-lg font-medium text-gray-800">Active Shipments</h3>
        <div className="flex items-center text-sm text-gray-600">
          <span>Last updated: </span>
          <span className="ml-1 text-primary" id="last-updated-time">{formatLastUpdated()}</span>
          <button 
            onClick={handleRefresh} 
            className="ml-2 text-primary hover:text-blue-800"
            aria-label="Refresh shipments"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto" id="shipment-list">
        {isLoading ? (
          <div className="p-4 text-center text-gray-500">
            <svg className="animate-spin h-5 w-5 mx-auto mb-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Loading shipments...
          </div>
        ) : shipments.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            No shipments found.
          </div>
        ) : (
          shipments.map((shipment) => (
            <ShipmentCard 
              key={shipment.id} 
              shipment={shipment} 
              isSelected={selectedShipmentId === shipment.shipmentId}
              onClick={() => onSelectShipment(shipment.shipmentId)}
            />
          ))
        )}
      </div>
    </Card>
  );
}
