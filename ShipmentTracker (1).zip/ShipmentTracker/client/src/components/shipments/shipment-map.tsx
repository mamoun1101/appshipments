import React, { useEffect, useRef } from "react";
import { Shipment } from "@/types";
import { getStatusColor } from "@/lib/shipment-utils";
import { Card } from "@/components/ui/card";

// Add Leaflet types to Window object
declare global {
  interface Window {
    L: any;
  }
}

interface ShipmentMapProps {
  shipments: Shipment[];
  selectedShipmentId?: string;
  onSelectShipment?: (shipmentId: string) => void;
}

export function ShipmentMap({ 
  shipments, 
  selectedShipmentId,
  onSelectShipment 
}: ShipmentMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const linesRef = useRef<any[]>([]);
  
  // Store map layers
  const mapLayersRef = useRef<{[key: string]: any}>({});
  
  // Initialize the map
  useEffect(() => {
    if (!mapRef.current) return;
    
    // Make sure Leaflet is available
    if (!window.L) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.7.1/dist/leaflet.css';
      document.head.appendChild(link);
      
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.7.1/dist/leaflet.js';
      script.onload = initializeMap;
      document.head.appendChild(script);
    } else {
      initializeMap();
    }
    
    function initializeMap() {
      if (mapInstanceRef.current) return;
      
      const L = window.L;
      const map = L.map(mapRef.current!).setView([39.8283, -98.5795], 4); // Center on US
      
      // Define base maps
      mapLayersRef.current = {
        standard: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
          maxZoom: 18
        }).addTo(map),
        satellite: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
          attribution: '&copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
          maxZoom: 18
        }),
        terrain: L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://opentopomap.org">OpenTopoMap</a> contributors',
          maxZoom: 18
        })
      };
      
      mapInstanceRef.current = map;
    }
    
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);
  
  // Update markers when shipments change
  useEffect(() => {
    if (!mapInstanceRef.current || !window.L || shipments.length === 0) return;
    
    const L = window.L;
    const map = mapInstanceRef.current;
    
    // Clear existing markers and lines
    markersRef.current.forEach(marker => marker.remove());
    linesRef.current.forEach(line => line.remove());
    markersRef.current = [];
    linesRef.current = [];
    
    // Add new markers
    shipments.forEach(shipment => {
      const { currentLat, currentLng, originLat, originLng, destinationLat, destinationLng, status, shipmentId } = shipment;
      
      // Skip if missing coordinates
      if (!currentLat || !currentLng || !originLat || !originLng || !destinationLat || !destinationLng) {
        return;
      }
      
      const color = getStatusColor(status).replace('bg-', '');
      
      // Create customized icon based on shipment status
      const statusIcon = L.divIcon({
        className: 'custom-div-icon',
        html: `<div style="background-color: var(--status-${status}); width: 15px; height: 15px; border-radius: 50%; border: 2px solid white;"></div>`,
        iconSize: [15, 15],
        iconAnchor: [8, 8]
      });
      
      // Add marker
      const marker = L.marker([parseFloat(currentLat), parseFloat(currentLng)], { 
        icon: statusIcon,
        zIndexOffset: shipmentId === selectedShipmentId ? 1000 : 0
      }).addTo(map);
      
      // Add popup
      marker.bindPopup(`
        <div class="text-sm font-medium">#${shipmentId}</div>
        <div class="text-xs mt-1">Status: ${status.replace('-', ' ').charAt(0).toUpperCase() + status.slice(1).replace('-', ' ')}</div>
        <button class="mt-2 text-xs text-blue-600 hover:underline view-details" data-id="${shipmentId}">View Details</button>
      `);
      
      // Add click handler
      marker.on('click', () => {
        if (onSelectShipment) {
          onSelectShipment(shipmentId);
        }
      });
      
      // Draw route line
      const routeLine = L.polyline([
        [parseFloat(originLat), parseFloat(originLng)],
        [parseFloat(currentLat), parseFloat(currentLng)],
        [parseFloat(destinationLat), parseFloat(destinationLng)]
      ], {
        color: getComputedStyle(document.documentElement).getPropertyValue(`--status-${status}`).trim() || '#3B82F6',
        weight: 3,
        opacity: 0.7,
        dashArray: status === 'in-transit' ? '5, 5' : null
      }).addTo(map);
      
      // Add origin/destination markers (smaller)
      const waypointIcon = L.divIcon({
        className: 'waypoint-div-icon',
        html: `<div style="background-color: #6B7280; width: 8px; height: 8px; border-radius: 50%; border: 1px solid white;"></div>`,
        iconSize: [8, 8],
        iconAnchor: [4, 4]
      });
      
      const originMarker = L.marker([parseFloat(originLat), parseFloat(originLng)], { icon: waypointIcon }).addTo(map);
      const destMarker = L.marker([parseFloat(destinationLat), parseFloat(destinationLng)], { icon: waypointIcon }).addTo(map);
      
      originMarker.bindTooltip(`Origin: ${shipment.originCity}, ${shipment.originState}`);
      destMarker.bindTooltip(`Destination: ${shipment.destinationCity}, ${shipment.destinationState}`);
      
      // Store references for cleanup
      markersRef.current.push(marker, originMarker, destMarker);
      linesRef.current.push(routeLine);
    });
    
    // Zoom to fit all markers
    if (markersRef.current.length > 0) {
      const group = L.featureGroup(markersRef.current);
      map.fitBounds(group.getBounds(), { padding: [30, 30] });
    }
  }, [shipments, selectedShipmentId, onSelectShipment]);

  return (
    <Card className="bg-white rounded-lg shadow-sm overflow-hidden h-full">
      <div className="bg-gray-50 px-4 py-3 flex items-center justify-between border-b">
        <h3 className="text-lg font-medium text-gray-800">Shipment Tracking Map</h3>
        <div className="flex space-x-2">
          <button 
            className="px-3 py-1 text-xs rounded border border-gray-300 bg-white text-gray-700 hover:bg-gray-50"
            onClick={() => {
              if (mapInstanceRef.current && markersRef.current.length > 0) {
                const L = window.L;
                const group = L.featureGroup(markersRef.current);
                mapInstanceRef.current.fitBounds(group.getBounds(), { padding: [30, 30] });
              }
            }}
          >
            <span className="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
              </svg>
              Zoom Fit
            </span>
          </button>
          <select 
            className="px-3 py-1 text-xs rounded border border-gray-300 bg-white text-gray-700"
            onChange={(e) => {
              const selectedLayer = e.target.value;
              if (mapInstanceRef.current && mapLayersRef.current) {
                // Remove all layers
                Object.values(mapLayersRef.current).forEach(layer => {
                  if (mapInstanceRef.current.hasLayer(layer)) {
                    mapInstanceRef.current.removeLayer(layer);
                  }
                });
                
                // Add the selected layer
                if (mapLayersRef.current[selectedLayer]) {
                  mapLayersRef.current[selectedLayer].addTo(mapInstanceRef.current);
                }
              }
            }}
          >
            <option value="standard">Standard View</option>
            <option value="satellite">Satellite View</option>
            <option value="terrain">Terrain View</option>
          </select>
        </div>
      </div>
      
      <div id="map" ref={mapRef} className="h-[500px] w-full lg:h-[516px]"></div>
      
      <div className="p-3 bg-gray-50 border-t">
        <div className="flex items-center justify-between text-sm">
          <div className="flex space-x-4">
            <div className="flex items-center">
              <span className="w-3 h-3 rounded-full bg-blue-500 mr-1"></span>
              <span className="text-gray-600">In Transit</span>
            </div>
            <div className="flex items-center">
              <span className="w-3 h-3 rounded-full bg-amber-500 mr-1"></span>
              <span className="text-gray-600">Delayed</span>
            </div>
            <div className="flex items-center">
              <span className="w-3 h-3 rounded-full bg-emerald-500 mr-1"></span>
              <span className="text-gray-600">Delivered</span>
            </div>
            <div className="flex items-center">
              <span className="w-3 h-3 rounded-full bg-red-500 mr-1"></span>
              <span className="text-gray-600">Issue</span>
            </div>
          </div>
          <div className="text-gray-500">
            <span id="total-visible-shipments">{shipments.length}</span> shipments visible
          </div>
        </div>
      </div>
    </Card>
  );
}
