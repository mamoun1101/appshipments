import React from "react";
import { ShipmentStatus } from "@/types";
import { cn } from "@/lib/utils";
import { getStatusColor } from "@/lib/shipment-utils";

interface ProgressBarProps {
  progress: number;
  status: ShipmentStatus;
  startLabel?: string;
  endLabel?: string;
  className?: string;
}

export function ProgressBar({ 
  progress, 
  status, 
  startLabel, 
  endLabel,
  className
}: ProgressBarProps) {
  const barColor = getStatusColor(status);

  return (
    <div className={cn("w-full", className)}>
      <div className="w-full bg-gray-200 rounded-full h-1.5">
        <div 
          className={cn("h-1.5 rounded-full", barColor)} 
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      
      {(startLabel || endLabel) && (
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          {startLabel && <span>{startLabel}</span>}
          {endLabel && <span>{endLabel}</span>}
        </div>
      )}
    </div>
  );
}
