import React from "react";
import { ShipmentStatus } from "@/types";
import { cn } from "@/lib/utils";
import { getStatusBgColor, getStatusTextColor, formatStatus } from "@/lib/shipment-utils";

interface StatusBadgeProps {
  status: ShipmentStatus;
  className?: string;
  showDot?: boolean;
}

export function StatusBadge({ status, className, showDot = true }: StatusBadgeProps) {
  const bgColor = getStatusBgColor(status);
  const textColor = getStatusTextColor(status);
  const statusDotColor = status === 'in-transit' ? 'bg-blue-500' : 
                         status === 'delayed' ? 'bg-amber-500' : 
                         status === 'delivered' ? 'bg-emerald-500' : 
                         'bg-red-500';

  return (
    <span className={cn(
      "px-2 py-0.5 rounded text-xs font-medium flex items-center",
      bgColor,
      textColor,
      className
    )}>
      {showDot && (
        <span className="inline-block w-2 h-2 rounded-full mr-1.5" style={{backgroundColor: `var(--status-${status})`}}></span>
      )}
      {formatStatus(status)}
    </span>
  );
}
