import { useEffect, useState, useRef } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Shipment, ShipmentFilters, ShipmentAlert, WebSocketMessage } from "../types";

// Custom hook for shipment data management
export function useShipments(filters?: ShipmentFilters) {
  const queryClient = useQueryClient();
  const [lastUpdateId, setLastUpdateId] = useState<number>(0);
  const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // Set up polling for real-time updates
  useEffect(() => {
    console.log('Setting up real-time updates with polling');
    
    const pollForUpdates = async () => {
      try {
        const response = await fetch(`/api/updates?since=${lastUpdateId}`);
        const updates = await response.json();
        
        if (updates && updates.length > 0) {
          console.log(`Received ${updates.length} updates`);
          
          // Update the last update ID
          const maxId = Math.max(...updates.map((update: any) => update.id));
          setLastUpdateId(maxId);
          
          // Process each update
          updates.forEach((update: any) => {
            const { data } = update;
            
            // Handle different message types
            switch (data.type) {
              case 'shipment_updated':
              case 'new_shipment':
                if (data.shipment) {
                  // Update shipment in cache
                  queryClient.invalidateQueries({ queryKey: ['/api/shipments'] });
                }
                break;
              case 'alert_updated':
                if (data.alert) {
                  // Update alerts in cache
                  queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
                }
                break;
            }
          });
        }
      } catch (error) {
        console.error('Error polling for updates:', error);
      }
    };
    
    // Poll every 3 seconds
    pollingIntervalRef.current = setInterval(pollForUpdates, 3000);
    
    // Initial poll
    pollForUpdates();
    
    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
    };
  }, [queryClient, lastUpdateId]);
  
  // Build query string from filters
  const getQueryString = () => {
    if (!filters) return '';
    
    const params = new URLSearchParams();
    
    if (filters.shipmentId) {
      params.append('shipmentId', filters.shipmentId);
    }
    
    if (filters.status) {
      params.append('status', filters.status);
    }
    
    if (filters.customerId) {
      params.append('customerId', filters.customerId);
    }
    
    if (filters.dateRange && filters.dateRange !== 'all') {
      params.append('dateRange', filters.dateRange);
      
      // Include specific date params for custom date range
      if (filters.dateRange === 'custom') {
        if (filters.dateFrom) {
          params.append('dateFrom', filters.dateFrom);
          console.log('Adding dateFrom parameter:', filters.dateFrom);
        }
        
        if (filters.dateTo) {
          params.append('dateTo', filters.dateTo);
          console.log('Adding dateTo parameter:', filters.dateTo);
        }
      }
      
      // Log applied filter for debugging
      console.log(`Applying date range filter: ${filters.dateRange}`);
      
      // Include dateRange in the query key to ensure it triggers a refetch when changed
      params.append('dateRangeKey', filters.dateRange);
    }
    
    const queryString = params.toString() ? `?${params.toString()}` : '';
    console.log(`Generated query string: ${queryString}`);
    return queryString;
  };
  
  // Fetch shipments
  const { data: shipments, isLoading, error } = useQuery<Shipment[]>({
    queryKey: ['/api/shipments' + getQueryString()],
    refetchInterval: 30000, // Refetch every 30 seconds as fallback if WebSocket fails
  });
  
  // Fetch alerts
  const { data: alerts = [] } = useQuery<ShipmentAlert[]>({
    queryKey: ['/api/alerts'],
    refetchInterval: 30000,
  });
  
  // Set up polling for simulating real-time updates
  useEffect(() => {
    const intervalId = setInterval(() => {
      // Simulate updates every 10 seconds
      fetch('/api/simulate-update', { method: 'POST' })
        .catch(err => console.error('Error simulating update:', err));
    }, 10000);
    
    return () => clearInterval(intervalId);
  }, []);
  
  // Mark an alert as read
  const markAlertAsRead = async (alertId: number) => {
    try {
      await fetch(`/api/alerts/${alertId}`, {
        method: 'PATCH',
      });
      
      // Invalidate alerts query to refetch
      queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
    } catch (error) {
      console.error('Error marking alert as read:', error);
    }
  };
  
  return {
    shipments: shipments || [],
    alerts,
    isLoading,
    error,
    markAlertAsRead,
  };
}
