import { ShipmentStatus, Shipment } from "../types";

/**
 * Get color for shipment status
 */
export function getStatusColor(status: ShipmentStatus): string {
  switch (status) {
    case "in-transit":
      return "bg-blue-500";
    case "delayed":
      return "bg-amber-500";
    case "delivered":
      return "bg-emerald-500";
    case "issue":
      return "bg-red-500";
    default:
      return "bg-gray-500";
  }
}

/**
 * Get color for shipment status (for text)
 */
export function getStatusTextColor(status: ShipmentStatus): string {
  switch (status) {
    case "in-transit":
      return "text-blue-800";
    case "delayed":
      return "text-amber-800";
    case "delivered":
      return "text-emerald-800";
    case "issue":
      return "text-red-800";
  }
}

/**
 * Get background color for shipment status badges
 */
export function getStatusBgColor(status: ShipmentStatus): string {
  switch (status) {
    case "in-transit":
      return "bg-blue-100";
    case "delayed":
      return "bg-amber-100";
    case "delivered":
      return "bg-emerald-100";
    case "issue":
      return "bg-red-100";
  }
}

/**
 * Format display name for shipment status
 */
export function formatStatus(status: ShipmentStatus): string {
  switch (status) {
    case "in-transit":
      return "In Transit";
    case "delayed":
      return "Delayed";
    case "delivered":
      return "Delivered";
    case "issue":
      return "Has Issue";
    default:
      return status.charAt(0).toUpperCase() + status.slice(1).replace("-", " ");
  }
}

/**
 * Format date from ISO string to readable format 
 */
export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

/**
 * Format time from ISO string to readable format
 */
export function formatTime(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
}

/**
 * Calculate the distance between two coordinates
 */
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c; // Distance in km
  return Math.round(d * 0.621371); // Convert to miles and round
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

/**
 * Format a date relative to now (e.g. "2 minutes ago")
 */
export function formatRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diff < 60) {
    return `${diff} seconds ago`;
  } else if (diff < 3600) {
    return `${Math.floor(diff / 60)} minutes ago`;
  } else if (diff < 86400) {
    return `${Math.floor(diff / 3600)} hours ago`;
  } else {
    return formatDate(dateString);
  }
}

/**
 * Get statistics calculated from shipments
 */
export function calculateStats(shipments: Shipment[]): {
  total: number;
  inTransit: number;
  delayed: number;
  delivered: number;
  issues: number;
} {
  const inTransit = shipments.filter(s => s.status === "in-transit").length;
  const delayed = shipments.filter(s => s.status === "delayed").length;
  const delivered = shipments.filter(s => s.status === "delivered").length;
  const issues = shipments.filter(s => s.status === "issue").length;
  
  return {
    total: shipments.length,
    inTransit,
    delayed,
    delivered,
    issues
  };
}
