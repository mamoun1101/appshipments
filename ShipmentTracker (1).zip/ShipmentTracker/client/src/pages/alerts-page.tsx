import React from "react";
import { SidebarNav } from "@/components/layout/sidebar-nav";
import { MobileNav } from "@/components/layout/mobile-nav";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useShipments } from "@/hooks/use-shipments";
import { formatRelativeTime } from "@/lib/shipment-utils";
import { Bell, CheckCircle, AlertTriangle, Thermometer } from "lucide-react";

export default function AlertsPage() {
  const { user, logoutMutation } = useAuth();
  const { alerts, markAlertAsRead } = useShipments();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Group alerts by type
  const delayAlerts = alerts.filter(alert => alert.alertType === "delay");
  const issueAlerts = alerts.filter(alert => alert.alertType === "issue");
  const temperatureAlerts = alerts.filter(alert => alert.alertType === "temperature");
  const weatherAlerts = alerts.filter(alert => alert.alertType === "weather");
  
  // Get alert icon based on type
  const getAlertIcon = (type: string) => {
    switch (type) {
      case "delay":
        return <Bell className="h-5 w-5 text-amber-500" />;
      case "issue":
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case "temperature":
        return <Thermometer className="h-5 w-5 text-blue-500" />;
      case "weather":
        return <AlertTriangle className="h-5 w-5 text-purple-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <div className="min-h-screen flex bg-gray-50">
      <SidebarNav />

      <div className="flex-1 flex flex-col lg:ml-64">
        <header className="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6">
          <MobileNav />
          <div className="ml-auto flex items-center">
            <Button
              variant="ghost"
              className="text-sm text-gray-700"
              onClick={handleLogout}
            >
              Log Out
            </Button>
          </div>
        </header>

        <main className="flex-1 p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Alerts</h1>
            <p className="text-gray-500">View and manage alerts for all shipments.</p>
          </div>

          <div className="mb-6 flex justify-between">
            <div className="text-sm text-gray-500">
              {alerts.filter(a => !a.isRead).length} unread alerts
            </div>
            {alerts.some(a => !a.isRead) && (
              <Button variant="outline" size="sm">
                Mark All as Read
              </Button>
            )}
          </div>

          <div className="space-y-6">
            {alerts.length === 0 ? (
              <Card>
                <CardContent className="py-10 flex flex-col items-center justify-center">
                  <div className="bg-gray-100 rounded-full p-3 mb-3">
                    <Bell className="h-6 w-6 text-gray-400" />
                  </div>
                  <p className="text-gray-500">No alerts found. All shipments are proceeding normally.</p>
                </CardContent>
              </Card>
            ) : (
              <>
                {issueAlerts.length > 0 && (
                  <Card className="border-l-4 border-red-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
                        Issue Alerts
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {issueAlerts.map(alert => (
                          <div 
                            key={alert.id} 
                            className={`flex items-start p-3 rounded-md ${alert.isRead ? 'bg-gray-50' : 'bg-red-50'}`}
                          >
                            <div className="mr-3">
                              {getAlertIcon(alert.alertType)}
                            </div>
                            <div className="flex-1">
                              <p className="text-sm font-medium text-gray-900">{alert.message}</p>
                              <p className="text-xs text-gray-500 mt-1">
                                {formatRelativeTime(alert.createdAt)}
                              </p>
                            </div>
                            {!alert.isRead && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => markAlertAsRead(alert.id)}
                                className="text-gray-500 hover:text-gray-900"
                              >
                                <CheckCircle className="h-4 w-4" />
                                <span className="ml-1">Mark as Read</span>
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {delayAlerts.length > 0 && (
                  <Card className="border-l-4 border-amber-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <Bell className="h-5 w-5 text-amber-500 mr-2" />
                        Delay Alerts
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {delayAlerts.map(alert => (
                          <div 
                            key={alert.id} 
                            className={`flex items-start p-3 rounded-md ${alert.isRead ? 'bg-gray-50' : 'bg-amber-50'}`}
                          >
                            <div className="mr-3">
                              {getAlertIcon(alert.alertType)}
                            </div>
                            <div className="flex-1">
                              <p className="text-sm font-medium text-gray-900">{alert.message}</p>
                              <p className="text-xs text-gray-500 mt-1">
                                {formatRelativeTime(alert.createdAt)}
                              </p>
                            </div>
                            {!alert.isRead && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => markAlertAsRead(alert.id)}
                                className="text-gray-500 hover:text-gray-900"
                              >
                                <CheckCircle className="h-4 w-4" />
                                <span className="ml-1">Mark as Read</span>
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {temperatureAlerts.length > 0 && (
                  <Card className="border-l-4 border-blue-500">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <Thermometer className="h-5 w-5 text-blue-500 mr-2" />
                        Temperature Alerts
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {temperatureAlerts.map(alert => (
                          <div 
                            key={alert.id} 
                            className={`flex items-start p-3 rounded-md ${alert.isRead ? 'bg-gray-50' : 'bg-blue-50'}`}
                          >
                            <div className="mr-3">
                              {getAlertIcon(alert.alertType)}
                            </div>
                            <div className="flex-1">
                              <p className="text-sm font-medium text-gray-900">{alert.message}</p>
                              <p className="text-xs text-gray-500 mt-1">
                                {formatRelativeTime(alert.createdAt)}
                              </p>
                            </div>
                            {!alert.isRead && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => markAlertAsRead(alert.id)}
                                className="text-gray-500 hover:text-gray-900"
                              >
                                <CheckCircle className="h-4 w-4" />
                                <span className="ml-1">Mark as Read</span>
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}