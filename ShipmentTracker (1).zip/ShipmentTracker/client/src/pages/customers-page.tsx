import React from "react";
import { SidebarNav } from "@/components/layout/sidebar-nav";
import { MobileNav } from "@/components/layout/mobile-nav";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Customer } from "@/types";
import { UserRound } from "lucide-react";

export default function CustomersPage() {
  const { user, logoutMutation } = useAuth();
  
  // Fetch customers
  const { data: customers = [], isLoading } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="min-h-screen flex bg-gray-50">
      <SidebarNav />

      <div className="flex-1 flex flex-col lg:ml-64">
        <header className="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6">
          <MobileNav />
          <div className="ml-auto flex items-center">
            <Button
              variant="ghost"
              className="text-sm text-gray-700"
              onClick={handleLogout}
            >
              Log Out
            </Button>
          </div>
        </header>

        <main className="flex-1 p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Customers</h1>
            <p className="text-gray-500">Manage your customer accounts and contact information.</p>
          </div>

          <div className="flex justify-between mb-6">
            <div className="flex space-x-4">
              <Button className="bg-primary text-white">
                Add New Customer
              </Button>
              <Button variant="outline">
                Import Customers
              </Button>
            </div>
            <div>
              <Button variant="outline">
                Export Customer List
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {isLoading ? (
              <p>Loading customers...</p>
            ) : customers.length === 0 ? (
              <p>No customers found.</p>
            ) : (
              customers.map((customer) => (
                <Card key={customer.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                        <UserRound className="h-5 w-5 text-primary" />
                      </div>
                      {customer.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-start">
                        <span className="text-gray-500 w-20">Email:</span>
                        <span className="text-gray-900">{customer.email}</span>
                      </div>
                      <div className="flex items-start">
                        <span className="text-gray-500 w-20">Phone:</span>
                        <span className="text-gray-900">{customer.phone || 'N/A'}</span>
                      </div>
                      <div className="flex items-start">
                        <span className="text-gray-500 w-20">Address:</span>
                        <span className="text-gray-900">{customer.address || 'N/A'}</span>
                      </div>
                      <div className="flex items-start pt-2">
                        <Button variant="outline" size="sm" className="mr-2">
                          View Details
                        </Button>
                        <Button variant="outline" size="sm">
                          Edit
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </main>
      </div>
    </div>
  );
}