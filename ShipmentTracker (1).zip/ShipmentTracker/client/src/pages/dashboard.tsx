import React, { useState, useEffect } from "react";
import { SidebarNav } from "@/components/layout/sidebar-nav";
import { MobileNav } from "@/components/layout/mobile-nav";
import { AlertBanner } from "@/components/dashboard/alert-banner";
import { FilterBar } from "@/components/dashboard/filter-bar";
import { StatsOverview } from "@/components/dashboard/stats-overview";
import { ShipmentList } from "@/components/shipments/shipment-list";
import { ShipmentMap } from "@/components/shipments/shipment-map";
import { ShipmentDetailsModal } from "@/components/shipments/shipment-details-modal";
import { NewShipmentModal } from "@/components/shipments/new-shipment-modal";
import { useShipments } from "@/hooks/use-shipments";
import { ShipmentFilters } from "@/types";
import { Plus, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

export default function Dashboard() {
  // State for filters
  const [filters, setFilters] = useState<ShipmentFilters>({});
  
  // State for selected shipment
  const [selectedShipmentId, setSelectedShipmentId] = useState<string | undefined>();
  
  // State for details modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // State for new shipment modal
  const [isNewShipmentModalOpen, setIsNewShipmentModalOpen] = useState(false);
  
  // Fetch shipments with filters
  const { shipments, alerts, isLoading, markAlertAsRead } = useShipments(filters);
  
  // Fetch stats
  const { data: stats } = useQuery({
    queryKey: ['/api/stats'],
  });
  
  // Select a shipment when clicked
  const handleSelectShipment = (shipmentId: string) => {
    setSelectedShipmentId(shipmentId);
    setIsModalOpen(true);
  };
  
  // Find the selected shipment object
  const selectedShipment = shipments.find(s => s.shipmentId === selectedShipmentId);
  
  // Handle filter changes
  const handleFilterChange = (newFilters: ShipmentFilters) => {
    setFilters(newFilters);
  };
  
  // Reset filters
  const handleResetFilters = () => {
    setFilters({});
  };
  
  // State for toggling filter bar visibility - default to true to show filters initially
  const [showFilterBar, setShowFilterBar] = useState(true);

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-gray-100">
      {/* Sidebar Navigation (Desktop) */}
      <SidebarNav />
      
      {/* Mobile Header & Menu */}
      <MobileNav />
      
      {/* Main Content */}
      <main className="flex-1 lg:ml-64 relative">
        <div className="p-6">
          {/* Alert Banner (if there are active alerts) */}
          {alerts.length > 0 && (
            <AlertBanner 
              alert={alerts[0]} 
              onDismiss={markAlertAsRead} 
            />
          )}
          
          {/* Page Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h2 className="text-2xl font-semibold text-gray-800">Shipment Dashboard</h2>
              <p className="mt-1 text-sm text-gray-600">Track and manage all active shipments in real-time.</p>
            </div>
            <div className="mt-4 md:mt-0">
              <Button 
                className="bg-primary text-white shadow-sm hover:bg-blue-800 mr-2"
                onClick={() => setIsNewShipmentModalOpen(true)}
              >
                <Plus className="h-5 w-5 mr-1" />
                New Shipment
              </Button>
              <Button 
                variant="outline" 
                className={`bg-white text-gray-600 shadow-sm border border-gray-300 hover:bg-gray-50 ${showFilterBar ? 'bg-gray-100' : ''}`}
                onClick={() => setShowFilterBar(!showFilterBar)}
              >
                <Filter className="h-5 w-5 mr-1" />
                Filter
              </Button>
            </div>
          </div>
          
          {/* Filter Bar - only show when toggled */}
          {showFilterBar && (
            <FilterBar 
              filters={filters} 
              onFilterChange={handleFilterChange} 
              onResetFilters={handleResetFilters} 
            />
          )}
          
          {/* Dashboard Stats */}
          {stats && <StatsOverview stats={stats} />}
          
          {/* Main Content Area - Shipment List and Map View */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Shipment List */}
            <div className="lg:col-span-5">
              <ShipmentList 
                shipments={shipments} 
                isLoading={isLoading} 
                selectedShipmentId={selectedShipmentId}
                onSelectShipment={handleSelectShipment}
              />
            </div>
            
            {/* Map View */}
            <div className="lg:col-span-7">
              <ShipmentMap 
                shipments={shipments} 
                selectedShipmentId={selectedShipmentId}
                onSelectShipment={handleSelectShipment}
              />
            </div>
          </div>
          
          {/* Shipment Details Modal */}
          <ShipmentDetailsModal 
            shipment={selectedShipment || null} 
            isOpen={isModalOpen} 
            onClose={() => setIsModalOpen(false)} 
          />
          
          {/* New Shipment Modal */}
          <NewShipmentModal
            isOpen={isNewShipmentModalOpen}
            onClose={() => setIsNewShipmentModalOpen(false)}
          />
        </div>
      </main>
    </div>
  );
}
