import React from "react";
import { SidebarNav } from "@/components/layout/sidebar-nav";
import { MobileNav } from "@/components/layout/mobile-nav";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { useShipments } from "@/hooks/use-shipments";
import { FileDown, Calendar, BarChart3 } from "lucide-react";

export default function ReportsPage() {
  const { user, logoutMutation } = useAuth();
  const { shipments } = useShipments();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Calculate stats for charts
  const statusCounts = {
    inTransit: shipments.filter(s => s.status === 'in-transit').length,
    delivered: shipments.filter(s => s.status === 'delivered').length,
    delayed: shipments.filter(s => s.status === 'delayed').length,
    issue: shipments.filter(s => s.status === 'issue').length
  };

  // Data for pie chart
  const pieData = [
    { name: "In Transit", value: statusCounts.inTransit, color: "#3B82F6" },
    { name: "Delivered", value: statusCounts.delivered, color: "#10B981" },
    { name: "Delayed", value: statusCounts.delayed, color: "#F59E0B" },
    { name: "Issues", value: statusCounts.issue, color: "#EF4444" }
  ];

  // Fake data for weekly shipment volume
  const weeklyData = [
    { name: "Mon", shipments: 12 },
    { name: "Tue", shipments: 19 },
    { name: "Wed", shipments: 15 },
    { name: "Thu", shipments: 18 },
    { name: "Fri", shipments: 24 },
    { name: "Sat", shipments: 10 },
    { name: "Sun", shipments: 8 }
  ];

  return (
    <div className="min-h-screen flex bg-gray-50">
      <SidebarNav />

      <div className="flex-1 flex flex-col lg:ml-64">
        <header className="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6">
          <MobileNav />
          <div className="ml-auto flex items-center">
            <Button
              variant="ghost"
              className="text-sm text-gray-700"
              onClick={handleLogout}
            >
              Log Out
            </Button>
          </div>
        </header>

        <main className="flex-1 p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Reports & Analytics</h1>
            <p className="text-gray-500">View and download shipment reports and statistics.</p>
          </div>

          <div className="mb-6 flex justify-between">
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-1" />
                Last 7 Days
              </Button>
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-1" />
                Last 30 Days
              </Button>
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-1" />
                Last Quarter
              </Button>
            </div>
            <Button variant="outline" size="sm">
              <FileDown className="h-4 w-4 mr-1" />
              Export Report
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <BarChart3 className="h-5 w-5 text-gray-500 mr-2" />
                  Weekly Shipment Volume
                </CardTitle>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={weeklyData}
                    margin={{ top: 20, right: 20, left: 20, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="shipments" fill="var(--status-in-transit)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <BarChart3 className="h-5 w-5 text-gray-500 mr-2" />
                  Shipment Status Distribution
                </CardTitle>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={80}
                      outerRadius={120}
                      fill="#8884d8"
                      paddingAngle={2}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Legend />
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Popular Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-gray-50 rounded-md cursor-pointer hover:bg-gray-100">
                    <div className="font-medium">Delivery Performance</div>
                    <div className="text-sm text-gray-500">Tracks on-time delivery rates and delays</div>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-md cursor-pointer hover:bg-gray-100">
                    <div className="font-medium">Route Efficiency</div>
                    <div className="text-sm text-gray-500">Analyzes optimal routes and actual paths</div>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-md cursor-pointer hover:bg-gray-100">
                    <div className="font-medium">Customer Shipment Summary</div>
                    <div className="text-sm text-gray-500">All shipments by customer with status</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 rounded-md">
                    <div className="text-sm text-gray-500 mb-1">Average Delivery Time</div>
                    <div className="text-2xl font-bold">3.2 days</div>
                    <div className="text-xs text-green-600 mt-1">↓ 0.5 days from last period</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-md">
                    <div className="text-sm text-gray-500 mb-1">On-Time Delivery Rate</div>
                    <div className="text-2xl font-bold">94.2%</div>
                    <div className="text-xs text-green-600 mt-1">↑ 2.1% from last period</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-md">
                    <div className="text-sm text-gray-500 mb-1">Issue Rate</div>
                    <div className="text-2xl font-bold">2.8%</div>
                    <div className="text-xs text-red-600 mt-1">↑ 0.3% from last period</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-md">
                    <div className="text-sm text-gray-500 mb-1">Customer Satisfaction</div>
                    <div className="text-2xl font-bold">4.7/5.0</div>
                    <div className="text-xs text-green-600 mt-1">↑ 0.2 from last period</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}