import React from "react";
import { SidebarNav } from "@/components/layout/sidebar-nav";
import { MobileNav } from "@/components/layout/mobile-nav";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Settings, User, Bell, Lock, Globe } from "lucide-react";

export default function SettingsPage() {
  const { user, logoutMutation } = useAuth();
  const [activeTab, setActiveTab] = React.useState("profile");

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="min-h-screen flex bg-gray-50">
      <SidebarNav />

      <div className="flex-1 flex flex-col lg:ml-64">
        <header className="bg-white shadow-sm border-b h-16 flex items-center justify-between px-6">
          <MobileNav />
          <div className="ml-auto flex items-center">
            <Button
              variant="ghost"
              className="text-sm text-gray-700"
              onClick={handleLogout}
            >
              Log Out
            </Button>
          </div>
        </header>

        <main className="flex-1 p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
            <p className="text-gray-500">Manage your account and application preferences.</p>
          </div>

          <Card>
            <CardContent className="p-0">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <div className="border-b">
                  <div className="px-4">
                    <TabsList className="h-14 w-full justify-start gap-6 bg-transparent">
                      <TabsTrigger 
                        value="profile"
                        className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
                      >
                        <User className="h-4 w-4 mr-2" />
                        Profile
                      </TabsTrigger>
                      <TabsTrigger 
                        value="account"
                        className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
                      >
                        <Lock className="h-4 w-4 mr-2" />
                        Account
                      </TabsTrigger>
                      <TabsTrigger 
                        value="notifications"
                        className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
                      >
                        <Bell className="h-4 w-4 mr-2" />
                        Notifications
                      </TabsTrigger>
                      <TabsTrigger 
                        value="appearance"
                        className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
                      >
                        <Settings className="h-4 w-4 mr-2" />
                        Appearance
                      </TabsTrigger>
                    </TabsList>
                  </div>
                </div>

                <TabsContent value="profile" className="p-6">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium">Profile Information</h3>
                      <p className="text-sm text-gray-500">Update your personal information and preferences.</p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="fullName">Full Name</Label>
                        <Input id="fullName" placeholder="John Davis" />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <Input id="email" type="email" placeholder="john.davis@example.com" />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="jobTitle">Job Title</Label>
                        <Input id="jobTitle" placeholder="Logistics Manager" />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="department">Department</Label>
                        <Input id="department" placeholder="Operations" />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input id="phone" placeholder="+1 (555) 123-4567" />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="timezone">Timezone</Label>
                        <select 
                          id="timezone" 
                          className="w-full border rounded-md py-2 px-3"
                        >
                          <option>America/New_York (EDT)</option>
                          <option>America/Chicago (CDT)</option>
                          <option>America/Denver (MDT)</option>
                          <option>America/Los_Angeles (PDT)</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      <Button className="bg-primary text-white">Save Changes</Button>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="account" className="p-6">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium">Account Security</h3>
                      <p className="text-sm text-gray-500">Manage your password and security settings.</p>
                    </div>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Change Password</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <form className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="currentPassword">Current Password</Label>
                            <Input id="currentPassword" type="password" />
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="newPassword">New Password</Label>
                            <Input id="newPassword" type="password" />
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="confirmPassword">Confirm New Password</Label>
                            <Input id="confirmPassword" type="password" />
                          </div>
                          
                          <Button className="bg-primary text-white">Update Password</Button>
                        </form>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Two-Factor Authentication</CardTitle>
                        <CardDescription>Add an extra layer of security to your account</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">Two-factor authentication is disabled</p>
                            <p className="text-sm text-gray-500">Protect your account with an extra verification step.</p>
                          </div>
                          <Button variant="outline">Enable</Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
                
                <TabsContent value="notifications" className="p-6">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium">Notification Preferences</h3>
                      <p className="text-sm text-gray-500">Control when and how you receive notifications.</p>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Shipment Status Updates</p>
                          <p className="text-sm text-gray-500">Receive notifications when shipment status changes.</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Delay Alerts</p>
                          <p className="text-sm text-gray-500">Get notified when shipments are delayed.</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Issue Reports</p>
                          <p className="text-sm text-gray-500">Receive notifications for shipment issues.</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Daily Summary</p>
                          <p className="text-sm text-gray-500">Receive a daily summary of all shipment activity.</p>
                        </div>
                        <Switch />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Marketing Updates</p>
                          <p className="text-sm text-gray-500">Receive news, updates, and promotional materials.</p>
                        </div>
                        <Switch />
                      </div>
                    </div>
                    
                    <div className="pt-4 border-t">
                      <h4 className="text-base font-medium mb-4">Notification Methods</h4>
                      
                      <div className="space-y-4">
                        <div className="grid grid-cols-3 gap-2 text-center text-sm bg-gray-50 p-2 rounded-md">
                          <div></div>
                          <div className="font-medium">Email</div>
                          <div className="font-medium">Push</div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-2 items-center">
                          <div>Shipment Status</div>
                          <div className="text-center"><Switch defaultChecked /></div>
                          <div className="text-center"><Switch defaultChecked /></div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-2 items-center">
                          <div>Alerts</div>
                          <div className="text-center"><Switch defaultChecked /></div>
                          <div className="text-center"><Switch defaultChecked /></div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-2 items-center">
                          <div>Summaries</div>
                          <div className="text-center"><Switch defaultChecked /></div>
                          <div className="text-center"><Switch /></div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      <Button className="bg-primary text-white">Save Preferences</Button>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="appearance" className="p-6">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium">Appearance Settings</h3>
                      <p className="text-sm text-gray-500">Customize the appearance of the application.</p>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-base font-medium mb-2">Theme</h4>
                        <div className="flex space-x-4">
                          <div className="flex items-center space-x-2">
                            <input type="radio" id="lightTheme" name="theme" defaultChecked />
                            <Label htmlFor="lightTheme">Light</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="radio" id="darkTheme" name="theme" />
                            <Label htmlFor="darkTheme">Dark</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="radio" id="systemTheme" name="theme" />
                            <Label htmlFor="systemTheme">System</Label>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-base font-medium mb-2">Dashboard Density</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span>Compact</span>
                            <span>Comfortable</span>
                          </div>
                          <Slider defaultValue={[50]} max={100} step={1} />
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-base font-medium mb-2">Font Size</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span>Small</span>
                            <span>Large</span>
                          </div>
                          <Slider defaultValue={[50]} max={100} step={1} />
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between pt-4">
                        <div>
                          <p className="font-medium">Show coordinates on map</p>
                          <p className="text-sm text-gray-500">Display latitude and longitude coordinates.</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Use animations</p>
                          <p className="text-sm text-gray-500">Enable animations for transitions and updates.</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Auto-refresh dashboard</p>
                          <p className="text-sm text-gray-500">Automatically refresh dashboard data.</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      <Button variant="outline" className="mr-2">Reset to Defaults</Button>
                      <Button className="bg-primary text-white">Save Settings</Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}