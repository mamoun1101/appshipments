import React, { useState, useEffect } from "react";
import { useShipments } from "@/hooks/use-shipments";
import { ShipmentFilters, Shipment } from "@/types";
import { Button } from "@/components/ui/button";
import { Plus, Filter } from "lucide-react";
import { SidebarNav } from "@/components/layout/sidebar-nav";
import { MobileNav } from "@/components/layout/mobile-nav";
import { FilterBar } from "@/components/dashboard/filter-bar";
import { NewShipmentModal } from "@/components/shipments/new-shipment-modal";
import { ShipmentDetailsModal } from "@/components/shipments/shipment-details-modal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { formatStatus, getStatusBgColor, formatDate } from "@/lib/shipment-utils";

export default function ShipmentsPage() {
  // State for filter toggling and modal controls
  const [filters, setFilters] = useState<ShipmentFilters>({});
  const [showFilterBar, setShowFilterBar] = useState(false);
  const [isNewShipmentModalOpen, setIsNewShipmentModalOpen] = useState(false);
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Fetch shipment data with the current filters
  const { shipments, isLoading } = useShipments(filters);

  // Handle filter changes
  const handleFilterChange = (newFilters: ShipmentFilters) => {
    setFilters(newFilters);
  };

  // Reset filters
  const handleResetFilters = () => {
    setFilters({});
  };

  // Handle shipment selection for details view
  const handleSelectShipment = (shipment: Shipment) => {
    setSelectedShipment(shipment);
    setIsModalOpen(true);
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-gray-100">
      {/* Sidebar Navigation (Desktop) */}
      <SidebarNav />
      
      {/* Mobile Header & Menu */}
      <MobileNav />
      
      {/* Main Content */}
      <main className="flex-1 lg:ml-64 relative">
        <div className="p-6">
          {/* Page Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h2 className="text-2xl font-semibold text-gray-800">Shipments</h2>
              <p className="mt-1 text-sm text-gray-600">
                View and manage all shipments in the system.
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <Button 
                className="bg-primary text-white shadow-sm hover:bg-blue-800 mr-2"
                onClick={() => setIsNewShipmentModalOpen(true)}
              >
                <Plus className="h-5 w-5 mr-1" />
                New Shipment
              </Button>
              <Button 
                variant="outline" 
                className={`bg-white text-gray-600 shadow-sm border border-gray-300 hover:bg-gray-50 ${showFilterBar ? 'bg-gray-100' : ''}`}
                onClick={() => setShowFilterBar(!showFilterBar)}
              >
                <Filter className="h-5 w-5 mr-1" />
                Filter
              </Button>
            </div>
          </div>
          
          {/* Filter Bar - only show when toggled */}
          {showFilterBar && (
            <FilterBar 
              filters={filters} 
              onFilterChange={handleFilterChange} 
              onResetFilters={handleResetFilters} 
            />
          )}
          
          {/* Shipments Table */}
          <Card className="shadow-sm bg-white">
            <CardHeader className="pb-2">
              <CardTitle>All Shipments</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center py-10">
                  <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Shipment ID</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Origin</TableHead>
                        <TableHead>Destination</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Created Date</TableHead>
                        <TableHead>Est. Delivery</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {shipments.map((shipment) => (
                        <TableRow 
                          key={shipment.id} 
                          className="cursor-pointer hover:bg-gray-50"
                          onClick={() => handleSelectShipment(shipment)}
                        >
                          <TableCell className="font-medium">{shipment.shipmentId}</TableCell>
                          <TableCell>
                            <Badge 
                              className="font-medium" 
                              style={{ backgroundColor: getStatusBgColor(shipment.status) }}
                            >
                              {formatStatus(shipment.status)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {shipment.originCity}, {shipment.originState}
                          </TableCell>
                          <TableCell>
                            {shipment.destinationCity}, {shipment.destinationState}
                          </TableCell>
                          <TableCell>{shipment.customerId}</TableCell>
                          <TableCell>{formatDate(shipment.createdAt)}</TableCell>
                          <TableCell>{formatDate(shipment.estimatedDelivery)}</TableCell>
                        </TableRow>
                      ))}
                      
                      {shipments.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-10 text-gray-500">
                            No shipments found matching your criteria.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Shipment Details Modal */}
          <ShipmentDetailsModal 
            shipment={selectedShipment} 
            isOpen={isModalOpen} 
            onClose={() => setIsModalOpen(false)} 
          />
          
          {/* New Shipment Modal */}
          <NewShipmentModal
            isOpen={isNewShipmentModalOpen}
            onClose={() => setIsNewShipmentModalOpen(false)}
          />
        </div>
      </main>
    </div>
  );
}