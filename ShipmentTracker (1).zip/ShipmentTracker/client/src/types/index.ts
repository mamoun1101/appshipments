export type ShipmentStatus = 'in-transit' | 'delayed' | 'delivered' | 'issue';

export interface Shipment {
  id: number;
  shipmentId: string;
  status: ShipmentStatus;
  customerId: number;
  originCity: string;
  originState: string;
  destinationCity: string;
  destinationState: string;
  currentLat: string;
  currentLng: string;
  originLat: string;
  originLng: string;
  destinationLat: string;
  destinationLng: string;
  progress: number;
  shipDate: string;
  estimatedDelivery: string;
  actualDelivery?: string;
  delayReason?: string;
  issueDescription?: string;
  serviceType?: string;
  serviceName?: string;
  orderReference: string;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: number;
  name: string;
  email: string;
  phone?: string;
  address?: string;
}

export interface ShipmentAlert {
  id: number;
  shipmentId: number;
  alertType: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface ShipmentUpdate {
  id: number;
  shipmentId: number;
  status: string;
  location?: string;
  lat?: string;
  lng?: string;
  description?: string;
  timestamp: string;
}

export interface ShipmentFilters {
  shipmentId?: string;
  status?: string;
  customerId?: string;
  dateRange?: string;
  dateFrom?: string;
  dateTo?: string;
}

export interface ShipmentStats {
  total: number;
  inTransit: number;
  delayed: number;
  delivered: number;
  issues: number;
  weeklyChange?: {
    total: number;
    inTransit: number;
    delayed: number;
    delivered: number;
  };
}

export interface WebSocketMessage {
  type: string;
  shipment?: Shipment;
  alert?: ShipmentAlert;
}
