import express, { Router, Response } from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage, ShipmentFilters } from "./storage";
import { WebSocketServer, WebSocket } from "ws";
import { z } from "zod";
import { insertShipmentSchema, ShipmentStatus } from "@shared/schema";
import { validateRequest } from "zod-express-middleware";
import { setupAuth, isAuthenticated } from "./auth";

// Extend Request type to include filters property
interface Request extends express.Request {
  filters?: ShipmentFilters;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  
  // Create HTTP server
  const httpServer = createServer(app);
  
  // For Replit environment, we'll use a different approach for real-time updates
  // Instead of WebSockets, we'll use HTTP endpoints with polling
  
  // Keep track of updates to broadcast
  let pendingUpdates: any[] = [];
  
  // Function to add updates to the pending queue
  const broadcast = (data: any) => {
    pendingUpdates.push({
      id: Date.now(),
      data,
      timestamp: new Date().toISOString()
    });
    
    // Keep only the last 100 updates
    if (pendingUpdates.length > 100) {
      pendingUpdates = pendingUpdates.slice(-100);
    }
    
    console.log(`Broadcasting update: ${JSON.stringify(data).substring(0, 100)}...`);
  };
  
  // Create API router
  const apiRouter = Router();
  
  // Middleware to parse query parameters
  const parseShipmentFilters = (req: Request, res: Response, next: Function) => {
    const filters: ShipmentFilters = {};
    
    if (req.query.shipmentId) {
      filters.shipmentId = req.query.shipmentId as string;
    }
    
    if (req.query.status) {
      filters.status = req.query.status as string;
    }
    
    if (req.query.customerId) {
      filters.customerId = parseInt(req.query.customerId as string);
    }
    
    // Handle date range filtering
    if (req.query.dateRange) {
      const dateRange = req.query.dateRange as string;
      const now = new Date();
      
      console.log(`Processing date range filter: ${dateRange}`);
      
      switch (dateRange) {
        case 'today':
          const todayStart = new Date(now);
          todayStart.setHours(0, 0, 0, 0);
          filters.dateFrom = todayStart;
          filters.dateTo = new Date();
          console.log(`Date filter set - from: ${filters.dateFrom.toISOString()} to: ${filters.dateTo.toISOString()}`);
          break;
          
        case 'yesterday':
          const yesterday = new Date(now);
          yesterday.setDate(yesterday.getDate() - 1);
          const yesterdayStart = new Date(yesterday);
          yesterdayStart.setHours(0, 0, 0, 0);
          const yesterdayEnd = new Date(yesterday);
          yesterdayEnd.setHours(23, 59, 59, 999);
          filters.dateFrom = yesterdayStart;
          filters.dateTo = yesterdayEnd;
          console.log(`Date filter set - from: ${filters.dateFrom.toISOString()} to: ${filters.dateTo.toISOString()}`);
          break;
          
        case 'last-7-days':
          const lastWeek = new Date(now);
          lastWeek.setDate(lastWeek.getDate() - 7);
          const lastWeekStart = new Date(lastWeek);
          lastWeekStart.setHours(0, 0, 0, 0);
          filters.dateFrom = lastWeekStart;
          filters.dateTo = new Date();
          console.log(`Date filter set - from: ${filters.dateFrom.toISOString()} to: ${filters.dateTo.toISOString()}`);
          break;
          
        case 'last-30-days':
          const lastMonth = new Date(now);
          lastMonth.setDate(lastMonth.getDate() - 30);
          const lastMonthStart = new Date(lastMonth);
          lastMonthStart.setHours(0, 0, 0, 0);
          filters.dateFrom = lastMonthStart;
          filters.dateTo = new Date();
          console.log(`Date filter set - from: ${filters.dateFrom.toISOString()} to: ${filters.dateTo.toISOString()}`);
          break;
          
        case 'custom':
          // Custom will be handled by explicit dateFrom and dateTo params
          console.log('Custom date range - waiting for dateFrom and dateTo params');
          break;
      }
    }
    
    // Direct date range parameters override dateRange selection
    if (req.query.dateFrom) {
      try {
        const dateStr = req.query.dateFrom as string;
        console.log(`Processing dateFrom parameter:`, dateStr);
        
        // Make sure date starts at beginning of day
        const date = new Date(dateStr);
        date.setHours(0, 0, 0, 0);
        
        filters.dateFrom = date;
        console.log(`Using explicit dateFrom filter: ${filters.dateFrom.toISOString()}`);
      } catch (e) {
        console.error(`Invalid dateFrom format: ${req.query.dateFrom}`, e);
      }
    }
    
    if (req.query.dateTo) {
      try {
        const dateStr = req.query.dateTo as string;
        console.log(`Processing dateTo parameter:`, dateStr);
        
        // Make sure date ends at end of day 
        const date = new Date(dateStr);
        date.setHours(23, 59, 59, 999);
        
        filters.dateTo = date;
        console.log(`Using explicit dateTo filter: ${filters.dateTo.toISOString()}`);
      } catch (e) {
        console.error(`Invalid dateTo format: ${req.query.dateTo}`, e);
      }
    }
    
    req.filters = filters;
    next();
  };
  
  // Get all shipments with optional filtering
  apiRouter.get("/shipments", isAuthenticated, parseShipmentFilters, async (req: Request, res: Response) => {
    try {
      const shipments = await storage.getShipments(req.filters);
      res.json(shipments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch shipments" });
    }
  });
  

  
  // Get a single shipment by ID
  apiRouter.get("/shipments/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const shipment = await storage.getShipmentByShipmentId(req.params.id);
      
      if (!shipment) {
        return res.status(404).json({ error: "Shipment not found" });
      }
      
      res.json(shipment);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch shipment" });
    }
  });
  
  // Get shipment updates/history
  apiRouter.get("/shipments/:id/updates", isAuthenticated, async (req: Request, res: Response) => {
    try {
      // First try to parse id as a number (internal numeric ID)
      let shipmentId: number;
      
      try {
        // Attempt to parse as numeric ID
        shipmentId = parseInt(req.params.id);
        console.log(`Looking for updates with numeric ID: ${shipmentId}`);
      } catch (e) {
        // If parsing fails, try to look up by shipmentId (string identifier)
        console.log(`Looking for shipment with string shipmentId: ${req.params.id}`);
        const shipment = await storage.getShipmentByShipmentId(req.params.id);
        
        if (!shipment) {
          return res.status(404).json({ error: "Shipment not found" });
        }
        
        shipmentId = shipment.id;
      }
      
      console.log(`Fetching updates for shipment ID: ${shipmentId}`);
      const updates = await storage.getShipmentUpdates(shipmentId);
      console.log(`Found ${updates.length} updates for shipment ID: ${shipmentId}`);
      res.json(updates);
    } catch (error) {
      console.error(`Error fetching shipment updates:`, error);
      res.status(500).json({ error: "Failed to fetch shipment updates" });
    }
  });
  
  // Create a new shipment
  apiRouter.post(
    "/shipments", 
    isAuthenticated,
    async (req: Request, res: Response) => {
      try {
        const data = req.body;

        // Log the raw data first
        console.log("Raw shipment data received:", JSON.stringify(data, null, 2));
        
        // Manually prepare the data with proper date handling
        const preparedData = {
          ...data,
          shipDate: data.shipDate ? new Date(data.shipDate) : null,
          estimatedDelivery: data.estimatedDelivery ? new Date(data.estimatedDelivery) : null,
          actualDelivery: data.actualDelivery ? new Date(data.actualDelivery) : null,
        };
        
        console.log("Prepared shipment data:", JSON.stringify(preparedData, null, 2));
        
        // Create the shipment using the manually prepared data
        const shipment = await storage.createShipment(preparedData);
        
        // Create initial update record
        await storage.createShipmentUpdate({
          shipmentId: shipment.id,
          status: shipment.status,
          lat: shipment.currentLat,
          lng: shipment.currentLng,
          description: "Shipment created",
          timestamp: new Date()
        });
        
        // Notify connected clients about the new shipment
        broadcast({ type: "shipment_created", shipment });
        
        res.status(201).json(shipment);
      } catch (error) {
        console.error("Error creating shipment:", error);
        console.error("Request body:", JSON.stringify(req.body, null, 2));
        if (error instanceof Error) {
          res.status(500).json({ error: `Failed to create shipment: ${error.message}` });
        } else {
          res.status(500).json({ error: "Failed to create shipment: Unknown error" });
        }
      }
    }
  );
  
  // Update a shipment's status and location
  apiRouter.patch("/shipments/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const shipment = await storage.getShipmentByShipmentId(req.params.id);
      
      if (!shipment) {
        return res.status(404).json({ error: "Shipment not found" });
      }
      
      const data = req.body;
      console.log("Raw shipment update data:", JSON.stringify(data, null, 2));

      // Prepare shipment data with proper date handling
      const preparedData: any = {
        ...data
      };
      
      // Handle dates if they're provided in the update
      if (data.shipDate) {
        preparedData.shipDate = new Date(data.shipDate);
      }
      
      if (data.estimatedDelivery) {
        preparedData.estimatedDelivery = new Date(data.estimatedDelivery);
      }
      
      if (data.actualDelivery) {
        preparedData.actualDelivery = new Date(data.actualDelivery);
      }
      
      console.log("Prepared shipment update data:", JSON.stringify(preparedData, null, 2));
      
      const updatedShipment = await storage.updateShipment(shipment.id, preparedData);
      
      // Create a shipment update record if location changed
      if (preparedData.currentLat && preparedData.currentLng && 
          (preparedData.currentLat !== shipment.currentLat || preparedData.currentLng !== shipment.currentLng)) {
        await storage.createShipmentUpdate({
          shipmentId: shipment.id,
          status: preparedData.status || shipment.status,
          lat: preparedData.currentLat,
          lng: preparedData.currentLng,
          description: `Location updated to ${preparedData.currentLat}, ${preparedData.currentLng}`,
          timestamp: new Date()
        });
      }
      
      // Create alert if status changed to DELAYED or ISSUE
      if (
        preparedData.status === "delayed" && 
        shipment.status !== "delayed"
      ) {
        const alertMessage = `Shipment #${shipment.shipmentId} has been delayed. ${preparedData.delayReason || ''}`;
        await storage.createShipmentAlert({
          shipmentId: shipment.id,
          alertType: "delay",
          message: alertMessage,
          isRead: false
        });
      } else if (
        preparedData.status === "issue" && 
        shipment.status !== "issue"
      ) {
        const alertMessage = `Issue detected with shipment #${shipment.shipmentId}. ${preparedData.issueDescription || ''}`;
        await storage.createShipmentAlert({
          shipmentId: shipment.id,
          alertType: "issue",
          message: alertMessage,
          isRead: false
        });
      }
      
      // Notify connected clients about the updated shipment
      broadcast({ type: "shipment_updated", shipment: updatedShipment });
      
      res.json(updatedShipment);
    } catch (error) {
      console.error("Error updating shipment:", error);
      console.error("Request body:", JSON.stringify(req.body, null, 2));
      if (error instanceof Error) {
        res.status(500).json({ error: `Failed to update shipment: ${error.message}` });
      } else {
        res.status(500).json({ error: "Failed to update shipment: Unknown error" });
      }
    }
  });
  
  // Get all alerts
  apiRouter.get("/alerts", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const alerts = await storage.getActiveAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });
  
  // Mark alert as read
  apiRouter.patch("/alerts/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const alert = await storage.markAlertAsRead(parseInt(req.params.id));
      
      // Notify connected clients about the updated alert
      broadcast({ type: "alert_updated", alert });
      
      res.json(alert);
    } catch (error) {
      res.status(500).json({ error: "Failed to update alert" });
    }
  });
  
  // Get all customers
  apiRouter.get("/customers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const customers = await storage.getCustomers();
      res.json(customers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch customers" });
    }
  });
  
  // Get dashboard stats
  apiRouter.get("/stats", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const stats = await storage.getShipmentStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch statistics" });
    }
  });
  
  // Simulate random shipment updates (for testing)
  apiRouter.post("/simulate-update", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const shipments = await storage.getShipments();
      if (shipments.length === 0) {
        return res.status(404).json({ error: "No shipments available" });
      }
      
      // Select a random shipment
      const randomIndex = Math.floor(Math.random() * shipments.length);
      const shipment = shipments[randomIndex];
      
      // Only update shipments that are in transit
      if (shipment.status !== "in-transit" && shipment.status !== "delayed") {
        return res.json({ message: "No eligible shipments for update" });
      }
      
      // Simulate progress update
      let newProgress = shipment.progress;
      if (shipment.progress < 100) {
        newProgress = Math.min(shipment.progress + Math.floor(Math.random() * 10), 100);
      }
      
      // Simulate location update (slight movement)
      const lat = parseFloat(shipment.currentLat);
      const lng = parseFloat(shipment.currentLng);
      
      // Move slightly toward destination
      const destLat = parseFloat(shipment.destinationLat);
      const destLng = parseFloat(shipment.destinationLng);
      
      const newLat = lat + (destLat - lat) * 0.1;
      const newLng = lng + (destLng - lng) * 0.1;
      
      // Update the shipment
      const updatedShipment = await storage.updateShipment(shipment.id, {
        currentLat: newLat.toString(),
        currentLng: newLng.toString(),
        progress: newProgress
      });
      
      // Create update record
      await storage.createShipmentUpdate({
        shipmentId: shipment.id,
        status: shipment.status,
        lat: newLat.toString(),
        lng: newLng.toString(),
        description: "Location automatically updated",
        timestamp: new Date()
      });
      
      // Notify connected clients
      broadcast({ type: "shipment_updated", shipment: updatedShipment });
      
      res.json(updatedShipment);
    } catch (error) {
      res.status(500).json({ error: "Failed to simulate update" });
    }
  });
  
  // Add endpoint for real-time updates polling
  apiRouter.get("/updates", isAuthenticated, (req: Request, res: Response) => {
    // Get the last update ID from the client
    const lastUpdateId = req.query.since ? parseInt(req.query.since as string) : 0;
    
    // Return all updates that occurred after the specified ID
    const updates = pendingUpdates.filter(update => update.id > lastUpdateId);
    
    res.json(updates);
  });
  
  // Mount API router
  app.use("/api", apiRouter);

  return httpServer;
}
