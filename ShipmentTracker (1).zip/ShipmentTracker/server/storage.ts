import { 
  Shipment, InsertShipment, 
  Customer, InsertCustomer,
  ShipmentAlert, InsertShipmentAlert,
  ShipmentUpdate, InsertShipmentUpdate,
  User, InsertUser,
  ShipmentStatus
} from "@shared/schema";
import { db } from "./db";
import connectPg from "connect-pg-simple";
import session from "express-session";
import { eq, like, and, or, between, gte, lte, desc, sql } from "drizzle-orm";
import * as schema from "@shared/schema";
import { Pool } from "pg";
// Remove count import

// Interface for storage operations
export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Customer operations
  getCustomer(id: number): Promise<Customer | undefined>;
  getCustomers(): Promise<Customer[]>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;

  // Shipment operations
  getShipment(id: number): Promise<Shipment | undefined>;
  getShipmentByShipmentId(shipmentId: string): Promise<Shipment | undefined>;
  getShipments(filters?: ShipmentFilters): Promise<Shipment[]>;
  createShipment(shipment: InsertShipment): Promise<Shipment>;
  updateShipment(id: number, shipment: Partial<Shipment>): Promise<Shipment>;

  // Alert operations
  getShipmentAlerts(shipmentId: number): Promise<ShipmentAlert[]>;
  createShipmentAlert(alert: InsertShipmentAlert): Promise<ShipmentAlert>;
  markAlertAsRead(id: number): Promise<ShipmentAlert>;
  getActiveAlerts(): Promise<ShipmentAlert[]>;

  // Shipment updates/history
  getShipmentUpdates(shipmentId: number): Promise<ShipmentUpdate[]>;
  createShipmentUpdate(update: InsertShipmentUpdate): Promise<ShipmentUpdate>;
  
  // Dashboard stats
  getShipmentStats(): Promise<ShipmentStats>;
  
  // Initialize sample data
  initSampleData(): Promise<void>;
}

// Types for filtering shipments
export interface ShipmentFilters {
  shipmentId?: string;
  status?: string;
  customerId?: number;
  dateFrom?: Date;
  dateTo?: Date;
}

// Type for shipment statistics
export interface ShipmentStats {
  total: number;
  inTransit: number;
  delayed: number;
  delivered: number;
  issues: number;
  weeklyChange?: {
    total: number;
    inTransit: number;
    delayed: number;
    delivered: number;
  };
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    const PostgresSessionStore = connectPg(session);
    this.sessionStore = new PostgresSessionStore({
      conObject: {
        connectionString: process.env.DATABASE_URL,
      },
      createTableIfMissing: true,
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(schema.users).values(user).returning();
    return newUser;
  }

  // Customer operations
  async getCustomer(id: number): Promise<Customer | undefined> {
    const [customer] = await db.select().from(schema.customers).where(eq(schema.customers.id, id));
    return customer;
  }

  async getCustomers(): Promise<Customer[]> {
    return await db.select().from(schema.customers);
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const [newCustomer] = await db.insert(schema.customers).values(customer).returning();
    return newCustomer;
  }

  // Shipment operations
  async getShipment(id: number): Promise<Shipment | undefined> {
    const [shipment] = await db.select().from(schema.shipments).where(eq(schema.shipments.id, id));
    return shipment;
  }

  async getShipmentByShipmentId(shipmentId: string): Promise<Shipment | undefined> {
    const [shipment] = await db.select().from(schema.shipments).where(eq(schema.shipments.shipmentId, shipmentId));
    return shipment;
  }

  async getShipments(filters?: ShipmentFilters): Promise<Shipment[]> {
    let queryBuilder = db.select().from(schema.shipments);
    
    if (filters) {
      const conditions = [];
      
      if (filters.shipmentId) {
        conditions.push(like(schema.shipments.shipmentId, `%${filters.shipmentId}%`));
      }
      
      if (filters.status) {
        conditions.push(eq(schema.shipments.status, filters.status as ShipmentStatus));
      }
      
      if (filters.customerId) {
        conditions.push(eq(schema.shipments.customerId, filters.customerId));
      }
      
      // Apply date filters to estimatedDelivery field (users are likely filtering by delivery date)
      if (filters.dateFrom && filters.dateTo) {
        try {
          // Create end of day for dateTo to include the full day
          const endDate = new Date(filters.dateTo);
          endDate.setHours(23, 59, 59, 999);
          
          console.log(`Applying date filter in DB query: ${filters.dateFrom.toISOString()} to ${endDate.toISOString()}`);
          conditions.push(
            and(
              gte(schema.shipments.estimatedDelivery, filters.dateFrom),
              lte(schema.shipments.estimatedDelivery, endDate)
            )
          );
        } catch (e) {
          console.error("Error applying date range filter:", e);
        }
      } else if (filters.dateFrom) {
        try {
          console.log(`Applying dateFrom filter in DB query: ${filters.dateFrom.toISOString()}`);
          conditions.push(gte(schema.shipments.estimatedDelivery, filters.dateFrom));
        } catch (e) {
          console.error("Error applying dateFrom filter:", e);
        }
      } else if (filters.dateTo) {
        try {
          // Create end of day for dateTo to include the full day
          const endDate = new Date(filters.dateTo);
          endDate.setHours(23, 59, 59, 999);
          
          console.log(`Applying dateTo filter in DB query: ${endDate.toISOString()}`);
          conditions.push(lte(schema.shipments.estimatedDelivery, endDate));
        } catch (e) {
          console.error("Error applying dateTo filter:", e);
        }
      }
      
      if (conditions.length > 0) {
        queryBuilder = queryBuilder.where(and(...conditions));
      }
    }
    
    const shipments = await queryBuilder;
    console.log(`Query returned ${shipments.length} shipments`);
    return shipments;
  }

  async createShipment(shipment: InsertShipment): Promise<Shipment> {
    const [newShipment] = await db.insert(schema.shipments).values(shipment).returning();
    return newShipment;
  }

  async updateShipment(id: number, shipment: Partial<Shipment>): Promise<Shipment> {
    const [updatedShipment] = await db.update(schema.shipments)
      .set({ ...shipment, updatedAt: new Date() })
      .where(eq(schema.shipments.id, id))
      .returning();
    
    if (!updatedShipment) {
      throw new Error(`Shipment with id ${id} not found`);
    }
    
    return updatedShipment;
  }

  // Alert operations
  async getShipmentAlerts(shipmentId: number): Promise<ShipmentAlert[]> {
    const alerts = await db.select()
      .from(schema.shipmentAlerts)
      .where(eq(schema.shipmentAlerts.shipmentId, shipmentId));
    return alerts;
  }

  async createShipmentAlert(alert: InsertShipmentAlert): Promise<ShipmentAlert> {
    const [newAlert] = await db.insert(schema.shipmentAlerts).values(alert).returning();
    return newAlert;
  }

  async markAlertAsRead(id: number): Promise<ShipmentAlert> {
    const [updatedAlert] = await db.update(schema.shipmentAlerts)
      .set({ isRead: true })
      .where(eq(schema.shipmentAlerts.id, id))
      .returning();
    
    if (!updatedAlert) {
      throw new Error(`Alert with id ${id} not found`);
    }
    
    return updatedAlert;
  }

  async getActiveAlerts(): Promise<ShipmentAlert[]> {
    const alerts = await db.select()
      .from(schema.shipmentAlerts)
      .where(eq(schema.shipmentAlerts.isRead, false))
      .orderBy(desc(schema.shipmentAlerts.createdAt));
    return alerts;
  }

  // Shipment updates/history
  async getShipmentUpdates(shipmentId: number): Promise<ShipmentUpdate[]> {
    const updates = await db.select()
      .from(schema.shipmentUpdates)
      .where(eq(schema.shipmentUpdates.shipmentId, shipmentId))
      .orderBy(desc(schema.shipmentUpdates.timestamp));
    return updates;
  }

  async createShipmentUpdate(update: InsertShipmentUpdate): Promise<ShipmentUpdate> {
    const [newUpdate] = await db.insert(schema.shipmentUpdates).values(update).returning();
    return newUpdate;
  }
  
  // Dashboard stats
  async getShipmentStats(): Promise<ShipmentStats> {
    const shipments = await db.select().from(schema.shipments);
    
    const total = shipments.length;
    const inTransit = shipments.filter(s => s.status === "in-transit").length;
    const delayed = shipments.filter(s => s.status === "delayed").length;
    const delivered = shipments.filter(s => s.status === "delivered").length;
    const issues = shipments.filter(s => s.status === "issue").length;
    
    return {
      total,
      inTransit,
      delayed,
      delivered,
      issues,
      weeklyChange: {
        total: 16, // Mock values for percentage change
        inTransit: 0,
        delayed: 12,
        delivered: 9
      }
    };
  }

  // Initialize the database with sample data when empty
  async initSampleData(): Promise<void> {
    try {
      // Check if we already have data
      const shipments = await db.select().from(schema.shipments);
      if (shipments.length > 0) {
        return; // Database already has data
      }

      // Create sample customers
      const customers = [
        { name: "Acme Corp", email: "contact@acmecorp.com", phone: "555-123-4567", address: "123 Main St, Anytown, USA" },
        { name: "Globex Inc", email: "info@globexinc.com", phone: "555-987-6543", address: "456 Tech Lane, Innovation City, USA" },
        { name: "Soylent Corp", email: "support@soylentcorp.com", phone: "555-456-7890", address: "789 Green Ave, Eco City, USA" },
        { name: "Initech LLC", email: "hello@initechllc.com", phone: "555-789-0123", address: "101 Office Park, Corporate City, USA" }
      ];
      
      for (const customer of customers) {
        await this.createCustomer(customer);
      }
      
      // Create sample shipments
      const shipmentData = [
        {
          shipmentId: "SHP-1092",
          status: "in-transit" as ShipmentStatus,
          customerId: 1,
          originCity: "Seattle",
          originState: "WA",
          destinationCity: "Portland",
          destinationState: "OR",
          currentLat: "47.2529",
          currentLng: "-122.4443",
          originLat: "47.6062",
          originLng: "-122.3321",
          destinationLat: "45.5152",
          destinationLng: "-122.6784",
          progress: 75,
          shipDate: new Date("2023-12-01T08:00:00"),
          estimatedDelivery: new Date("2023-12-03T16:30:00"),
          orderReference: "ORD-57832"
        },
        {
          shipmentId: "SHP-1093",
          status: "delayed" as ShipmentStatus,
          customerId: 2,
          originCity: "Chicago",
          originState: "IL",
          destinationCity: "New York",
          destinationState: "NY",
          currentLat: "41.8781",
          currentLng: "-88.6298",
          originLat: "41.8781",
          originLng: "-87.6298",
          destinationLat: "40.7128",
          destinationLng: "-74.0060",
          progress: 45,
          shipDate: new Date("2023-11-30T09:30:00"),
          estimatedDelivery: new Date("2023-12-02T14:00:00"),
          delayReason: "Severe weather conditions",
          orderReference: "ORD-43219"
        },
        {
          shipmentId: "SHP-1094",
          status: "delivered" as ShipmentStatus,
          customerId: 3,
          originCity: "Austin",
          originState: "TX",
          destinationCity: "Dallas",
          destinationState: "TX",
          currentLat: "32.7767",
          currentLng: "-96.7970",
          originLat: "30.2672",
          originLng: "-97.7431",
          destinationLat: "32.7767",
          destinationLng: "-96.7970",
          progress: 100,
          shipDate: new Date("2023-11-29T10:00:00"),
          estimatedDelivery: new Date("2023-11-30T12:00:00"),
          actualDelivery: new Date("2023-11-30T14:15:00"),
          orderReference: "ORD-76543"
        },
        {
          shipmentId: "SHP-1095",
          status: "in-transit" as ShipmentStatus,
          customerId: 4,
          originCity: "Los Angeles",
          originState: "CA",
          destinationCity: "San Francisco",
          destinationState: "CA",
          currentLat: "36.1699",
          currentLng: "-119.6044",
          originLat: "34.0522",
          originLng: "-118.2437",
          destinationLat: "37.7749",
          destinationLng: "-122.4194",
          progress: 60,
          shipDate: new Date("2023-11-30T14:30:00"),
          estimatedDelivery: new Date("2023-12-02T11:00:00"),
          orderReference: "ORD-12098"
        },
        {
          shipmentId: "SHP-1096",
          status: "issue" as ShipmentStatus,
          customerId: 1,
          originCity: "Miami",
          originState: "FL",
          destinationCity: "Atlanta",
          destinationState: "GA",
          currentLat: "30.9843",
          currentLng: "-83.2129",
          originLat: "25.7617",
          originLng: "-80.1918",
          destinationLat: "33.7490",
          destinationLng: "-84.3880",
          progress: 30,
          shipDate: new Date("2023-12-01T07:45:00"),
          estimatedDelivery: new Date("2023-12-04T09:00:00"),
          issueDescription: "Temperature alert - investigation required",
          orderReference: "ORD-38761"
        }
      ];
      
      for (const shipment of shipmentData) {
        await this.createShipment(shipment);
      }
      
      // Create sample alerts
      const alertData = [
        {
          shipmentId: 2,
          alertType: "delay",
          message: "Shipment #SHP-1093 is delayed by 3 hours due to severe weather conditions in Chicago, IL.",
          isRead: false
        },
        {
          shipmentId: 5,
          alertType: "temperature",
          message: "Temperature threshold exceeded for shipment #SHP-1096. Current: 29°C, Threshold: 25°C.",
          isRead: false
        }
      ];
      
      for (const alert of alertData) {
        await this.createShipmentAlert(alert);
      }
      
      // Create sample shipment updates/history
      const updateData = [
        {
          shipmentId: 1,
          status: "in-transit",
          location: "Tacoma, WA",
          lat: "47.2529",
          lng: "-122.4443",
          description: "Shipment in transit on I-5 South. Estimated arrival to Portland: 4:30 PM tomorrow.",
          timestamp: new Date("2023-12-02T10:35:00")
        },
        {
          shipmentId: 1,
          status: "departed",
          location: "Seattle Distribution Center",
          lat: "47.6062",
          lng: "-122.3321",
          description: "Shipment has left the Seattle distribution center. All items confirmed.",
          timestamp: new Date("2023-12-02T08:00:00")
        },
        {
          shipmentId: 1,
          status: "received",
          location: "Seattle Distribution Center",
          lat: "47.6062",
          lng: "-122.3321",
          description: "Shipment received at Seattle distribution center. Preparing for dispatch.",
          timestamp: new Date("2023-12-01T15:45:00")
        }
      ];
      
      for (const update of updateData) {
        await this.createShipmentUpdate(update);
      }
    } catch (error) {
      console.error("Error initializing sample data:", error);
      throw error;
    }
  }
}

// Create and export the storage instance
export const storage = new DatabaseStorage();

// Initialize sample data
storage.initSampleData().catch(err => {
  console.error("Failed to initialize sample data:", err);
});