import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for authentication (future feature)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Customers table
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  address: text("address"),
});

export const insertCustomerSchema = createInsertSchema(customers).pick({
  name: true,
  email: true,
  phone: true,
  address: true,
});

// Shipment status type
export type ShipmentStatus = "in-transit" | "delayed" | "delivered" | "issue";

// Shipments table
export const shipments = pgTable("shipments", {
  id: serial("id").primaryKey(),
  shipmentId: text("shipment_id").notNull().unique(), // business ID (e.g., SHP-1092)
  status: text("status").notNull().$type<"in-transit" | "delayed" | "delivered" | "issue">(),
  customerId: integer("customer_id").notNull(),
  originCity: text("origin_city").notNull(),
  originState: text("origin_state").notNull(),
  destinationCity: text("destination_city").notNull(),
  destinationState: text("destination_state").notNull(),
  currentLat: text("current_lat").notNull(), // latitude as string for precision
  currentLng: text("current_lng").notNull(), // longitude as string for precision
  originLat: text("origin_lat").notNull(),
  originLng: text("origin_lng").notNull(),
  destinationLat: text("destination_lat").notNull(),
  destinationLng: text("destination_lng").notNull(),
  progress: integer("progress").notNull(), // 0-100 percentage of journey completed
  shipDate: timestamp("ship_date"), // When the shipment left origin
  estimatedDelivery: timestamp("estimated_delivery"), // Estimated delivery date
  serviceType: text("service_type"), // e.g., ground, express, etc.
  serviceName: text("service_name"), // The specific service name
  actualDelivery: timestamp("actual_delivery"), // Actual delivery date if delivered
  delayReason: text("delay_reason"), // Reason for delay if any
  issueDescription: text("issue_description"), // Issue description if any
  orderReference: text("order_reference"), // Reference to order in external system
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Shipment insert schema
// Create the base schema, but replace date field validation with custom validation
const baseInsertShipmentSchema = createInsertSchema(shipments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Create a modified schema with string date fields that will be properly parsed
export const insertShipmentSchema = z.object({
  ...baseInsertShipmentSchema.shape,
  // Override the date fields to accept strings that we'll convert to dates
  shipDate: z.string().transform(val => val ? new Date(val) : null),
  estimatedDelivery: z.string().transform(val => val ? new Date(val) : null),
  actualDelivery: z.string().optional().transform(val => val ? new Date(val) : null),
});

// Shipment alerts table
export const shipmentAlerts = pgTable("shipment_alerts", {
  id: serial("id").primaryKey(),
  shipmentId: integer("shipment_id").notNull(),
  alertType: text("alert_type").notNull(), // delay, temperature, etc.
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertShipmentAlertSchema = createInsertSchema(shipmentAlerts).omit({
  id: true,
  createdAt: true,
});

// Shipment updates/history table
export const shipmentUpdates = pgTable("shipment_updates", {
  id: serial("id").primaryKey(),
  shipmentId: integer("shipment_id").notNull(),
  status: text("status").notNull(),
  location: text("location"),
  lat: text("lat"),
  lng: text("lng"),
  description: text("description"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertShipmentUpdateSchema = createInsertSchema(shipmentUpdates).omit({
  id: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type Shipment = typeof shipments.$inferSelect;
export type InsertShipment = z.infer<typeof insertShipmentSchema>;

export type ShipmentAlert = typeof shipmentAlerts.$inferSelect;
export type InsertShipmentAlert = z.infer<typeof insertShipmentAlertSchema>;

export type ShipmentUpdate = typeof shipmentUpdates.$inferSelect;
export type InsertShipmentUpdate = z.infer<typeof insertShipmentUpdateSchema>;
